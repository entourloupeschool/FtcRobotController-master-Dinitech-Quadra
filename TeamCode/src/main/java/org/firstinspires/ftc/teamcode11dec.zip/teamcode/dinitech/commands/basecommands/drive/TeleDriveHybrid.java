package org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.drive;

import com.acmerobotics.roadrunner.PoseVelocity2d;
import com.acmerobotics.roadrunner.Vector2d;
import com.arcrobotics.ftclib.command.CommandBase;

import org.firstinspires.ftc.teamcode.dinitech.subsytems.DriveSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.GamepadSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.devices.GamepadWrapper;

import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.TELE_DRIVE_POWER;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.TELE_DRIVE_POWER_TRIGGER_SCALE;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.pickCustomPowerFunc;

/**
 * Field-centric teleop drive command.
 * Left stick controls movement relative to the robot's initial orientation at
 * startup.
 * Right stick controls rotation.
 */
public class TeleDriveHybrid extends CommandBase {
    private final DriveSubsystem driveSubsystem;
    private final GamepadWrapper driver;

    private double lastTeleDriverPowerScale = TELE_DRIVE_POWER;

    // Store initial heading for field-centric control
    private double initialHeading = 0.0;
    private boolean headingInitialized = false;

    public TeleDriveHybrid(DriveSubsystem driveSubsystem, GamepadSubsystem gamepadSubsystem) {
        this.driveSubsystem = driveSubsystem;
        this.driver = gamepadSubsystem.driver;

        addRequirements(driveSubsystem);
    }

    @Override
    public void initialize() {
        // Capture initial heading
        resetFieldCentricHeading();
    }

    @Override
    public void execute() {
        // Get joystick inputs
        double translationX = driver.getLeftX();
        double translationY = driver.getLeftY();
        double rotation = driver.getRightX();
        double powerScaler = driver.getRightTriggerValue();

        // Update power scale based on trigger
        if (powerScaler != 0) {
            lastTeleDriverPowerScale = TELE_DRIVE_POWER_TRIGGER_SCALE * pickCustomPowerFunc(powerScaler, 1)
                    + TELE_DRIVE_POWER;
        }

        // Get current robot heading and calculate relative heading from start
        double currentHeading = driveSubsystem.dinitechMecanumDrive.localizer.getPose().heading.toDouble();
        double relativeHeading = currentHeading - initialHeading;

        // Transform field-centric inputs to robot-centric
        // Rotate the input vector by negative relative heading
        double cosHeading = Math.cos(-relativeHeading);
        double sinHeading = Math.sin(-relativeHeading);

        double robotX = translationY * cosHeading - translationX * sinHeading;
        double robotY = translationY * sinHeading + translationX * cosHeading;

        // Apply to drive with robot-centric velocities
        driveSubsystem.dinitechMecanumDrive.setDrivePowers(new PoseVelocity2d(
                new Vector2d(
                        robotX * lastTeleDriverPowerScale,
                        -robotY * lastTeleDriverPowerScale),
                -rotation * lastTeleDriverPowerScale));
    }

    /**
     * Reset the field-centric heading reference to current robot heading.
     * Call this to redefine which direction is "forward" for field-centric control.
     */
    public void resetFieldCentricHeading() {
        initialHeading = driveSubsystem.dinitechMecanumDrive.localizer.getPose().heading.toDouble();
        headingInitialized = true;
    }

    @Override
    public void end(boolean interrupted) {
        // Stop the robot when command ends
        driveSubsystem.dinitechMecanumDrive.setDrivePowers(new PoseVelocity2d(
                new Vector2d(0, 0), 0));
    }
}
