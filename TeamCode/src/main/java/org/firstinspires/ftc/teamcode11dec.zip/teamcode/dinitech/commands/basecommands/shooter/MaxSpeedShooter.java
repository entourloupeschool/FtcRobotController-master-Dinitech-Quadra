package org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.shooter;

import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.MAX_SHOOT_SPEED;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.SPEED_MARGIN;

import com.arcrobotics.ftclib.command.CommandBase;

import org.firstinspires.ftc.teamcode.dinitech.subsytems.ShooterSubsystem;

public class MaxSpeedShooter extends CommandBase {
    private final ShooterSubsystem shooterSubsystem;


    public MaxSpeedShooter(ShooterSubsystem shooterSubsystem){
        this.shooterSubsystem = shooterSubsystem;

        addRequirements(shooterSubsystem);
    }

    @Override
    public void initialize(){
        shooterSubsystem.setVelocity(MAX_SHOOT_SPEED);
    }


    @Override
    public boolean isFinished() {
        return shooterSubsystem.isSpeedAround(MAX_SHOOT_SPEED, SPEED_MARGIN);
    }


}
