package org.firstinspires.ftc.teamcode.dinitech.subsytems;

import com.arcrobotics.ftclib.command.SubsystemBase;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.PIDFCoefficients;

import org.firstinspires.ftc.robotcore.external.Telemetry;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.devices.MoulinVelocityControlled;

/**
 * Minimal Trieur subsystem using velocity-controlled Moulin for PIDF
 * auto-tuning.
 * 
 * This is a simplified version of TrieurSubsystem with ONLY the moulin motor,
 * designed specifically for testing and tuning the velocity-controlled
 * implementation.
 */
public class TrieurSubsystemVelocity extends SubsystemBase {

    private final MoulinVelocityControlled moulin;
    private final Telemetry telemetry;

    public TrieurSubsystemVelocity(HardwareMap hardwareMap, final Telemetry telemetry) {
        moulin = new MoulinVelocityControlled(hardwareMap);
        this.telemetry = telemetry;
    }

    // ========== MOULIN CONTROL METHODS ==========

    public void rotateToMoulinPosition(int pos, boolean makeShort) {
        moulin.setMoulinPosition(pos, makeShort);
    }

    public int getMoulinPosition() {
        return moulin.getPosition();
    }

    public int getMoulinMotorPosition() {
        return moulin.getMotorPosition();
    }

    public int getMoulinMotorTargetPosition() {
        return moulin.getTargetPosition();
    }

    public int getMoulinMotorRemainingDistance() {
        return moulin.getRemainingDistance();
    }

    public void setMoulinPower(double power) {
        moulin.setPower(power);
    }

    public void setMoulinTargetPosition(int targetPosition) {
        moulin.setTargetPositionMotor(targetPosition);
    }

    public boolean shouldMoulinStopPower() {
        return moulin.shouldStopPower();
    }

    // ========== PIDF METHODS ==========

    public void setPIDF(double p, double i, double d, double f) {
        moulin.setPIDF(p, i, d, f);
    }

    public PIDFCoefficients getPIDF() {
        return moulin.getPIDF();
    }

    public com.qualcomm.robotcore.hardware.DcMotor.RunMode getMoulinRunMode() {
        return moulin.getRunMode();
    }

    public void setMoulinRunMode(com.qualcomm.robotcore.hardware.DcMotor.RunMode mode) {
        moulin.setRunMode(mode);
    }

    @Override
    public void periodic() {
        // CRITICAL: Update position control every loop iteration
        // This replaces the automatic behavior of RUN_TO_POSITION mode
        moulin.updatePositionControl();

        // Telemetry
        printMoulinTelemetry(telemetry);
    }

    /**
     * Telemetry for moulin motor
     */
    private void printMoulinTelemetry(final Telemetry telemetry) {
        telemetry.addLine("=== Moulin (Velocity Control) ===");
        telemetry.addData("Position", getMoulinMotorPosition());
        telemetry.addData("Target", getMoulinMotorTargetPosition());
        telemetry.addData("Remaining", getMoulinMotorRemainingDistance());
        telemetry.addData("Moulin Pos", getMoulinPosition());
        telemetry.addData("At Target", moulin.atTargetPosition());
    }
}
