package org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.trieur;

import org.firstinspires.ftc.teamcode.dinitech.subsytems.TrieurSubsystem;

public class MoulinNext extends MoulinToPosition {
    private final TrieurSubsystem trieurSubsystem;

    public MoulinNext(TrieurSubsystem trieurSubsystem) {
        // Pass dummy values to super() - we'll set the real target in initialize()
        super(trieurSubsystem, 0, false);
        this.trieurSubsystem = trieurSubsystem;
    }

    @Override
    public void initialize() {
        // Calculate the next position when the button is actually pressed
        moulinTargetPosition = trieurSubsystem.getNNextMoulinPosition(trieurSubsystem.getMoulinPosition(), 1);
        makeShort = false;
        
        // Call parent's initialize() to start the movement
        super.initialize();
    }
}
