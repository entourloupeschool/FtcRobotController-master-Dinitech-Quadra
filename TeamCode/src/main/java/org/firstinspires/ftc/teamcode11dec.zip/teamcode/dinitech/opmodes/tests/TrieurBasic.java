package org.firstinspires.ftc.teamcode.dinitech.opmodes.tests;

import com.arcrobotics.ftclib.command.InstantCommand;
import com.arcrobotics.ftclib.command.button.Button;
import com.arcrobotics.ftclib.command.button.GamepadButton;
import com.arcrobotics.ftclib.gamepad.GamepadEx;
import com.arcrobotics.ftclib.gamepad.GamepadKeys;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.Gamepad;

import org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.trieur.ToggleTrappe;
import org.firstinspires.ftc.teamcode.dinitech.opmodes.DinitechRobotBase;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.ShooterSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.TrieurSubsystem;

@TeleOp(name="TrieurBasic - Dinitech", group="Test")

public class TrieurBasic extends DinitechRobotBase {
    // Gamepads
    private GamepadEx m_driver;
    private Button cross1, square1, circle1, triangle1, dpad_up, dpad_down, dpad_left, dpad_right;

    private TrieurSubsystem trieurSubsystem;
    private ShooterSubsystem shooterSubsystem;
    private double powerToApply = 0;


    /**
     * Initialize the teleop OpMode, gamepads, buttons, and default commands.
     */
    @Override
    public void initialize() {
        super.initialize();

        trieurSubsystem = new TrieurSubsystem(hardwareMap, telemetry);
        register(trieurSubsystem);

        shooterSubsystem = new ShooterSubsystem(hardwareMap, telemetry);
        register(shooterSubsystem);

        setupGamePadsButtonBindings();

    }

    /**
     * Main OpMode loop. Updates gamepad states.
     */
    @Override
    public void run() {
        super.run();
    }

    /**
     * Setup GamePads and Buttons and their associated commands.
     */
    private void setupGamePadsButtonBindings() {
        m_driver = new GamepadEx(gamepad1);

        dpad_up = new GamepadButton(m_driver, GamepadKeys.Button.DPAD_UP);
        dpad_down = new GamepadButton(m_driver, GamepadKeys.Button.DPAD_DOWN);
        dpad_left = new GamepadButton(m_driver, GamepadKeys.Button.DPAD_LEFT);
        dpad_right = new GamepadButton(m_driver, GamepadKeys.Button.DPAD_RIGHT);

        square1 = new GamepadButton(m_driver, GamepadKeys.Button.X);
        cross1 = new GamepadButton(m_driver, GamepadKeys.Button.A);
        circle1 = new GamepadButton(m_driver, GamepadKeys.Button.B);
        triangle1 = new GamepadButton(m_driver, GamepadKeys.Button.Y);

        /**
         * Bind analog position (double m_driver.getRightY()) to servo's incrementalRotation (double increment)
         */
        circle1.whenPressed(new ToggleTrappe(trieurSubsystem));

        dpad_up.whenPressed(new InstantCommand(() -> {
            powerToApply += 0.05;
            if (powerToApply > 1){
                powerToApply = 1;
            }
            shooterSubsystem.setVelocity(powerToApply);
        }));
        dpad_down.whenPressed(new InstantCommand(() -> {
            powerToApply -= 0.05;
            if (powerToApply < -1){
                powerToApply = -1;
            }
            shooterSubsystem.setVelocity(powerToApply);
        }));
        dpad_left.whenPressed(new InstantCommand(() -> {
            powerToApply = 0;
            shooterSubsystem.setVelocity(powerToApply);
        }));



    }
}
