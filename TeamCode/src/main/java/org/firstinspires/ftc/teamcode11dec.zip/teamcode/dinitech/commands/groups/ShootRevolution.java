package org.firstinspires.ftc.teamcode.dinitech.commands.groups;

import com.arcrobotics.ftclib.command.Command;
import com.arcrobotics.ftclib.command.ParallelCommandGroup;
import com.arcrobotics.ftclib.command.SequentialCommandGroup;
import com.arcrobotics.ftclib.command.WaitCommand;

import org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.shooter.MaxSpeedShooter;
import org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.shooter.StopShooter;
import org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.trieur.CloseTrappe;
import org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.trieur.MoulinRevolution;
import org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.trieur.OpenTrappe;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.ChargeurSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.ShooterSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.TrieurSubsystem;

public class ShootRevolution extends SequentialCommandGroup {
    private final TrieurSubsystem trieurSubsystem;
    private final ShooterSubsystem shooterSubsystem;

    /**
     * Creates a ShootRevolution Sequential Command Group
     *
     * @param trieurSubsystem       this command will run on
     * @param shooterSubsystem      the shooter subsystem
     */

    public ShootRevolution(TrieurSubsystem trieurSubsystem, ShooterSubsystem shooterSubsystem) {
        this.trieurSubsystem = trieurSubsystem;
        this.shooterSubsystem = shooterSubsystem;

        addCommands(
                new ParallelCommandGroup(
                        new MaxSpeedShooter(shooterSubsystem),
                        new OpenTrappe(trieurSubsystem)),
                new MoulinRevolution(trieurSubsystem),
                new WaitCommand(100),
                new ParallelCommandGroup(
                        new CloseTrappe(trieurSubsystem),
                        new StopShooter(shooterSubsystem)));
    }

    /**
     * Protected constructor for subclasses to provide custom shooter command
     *
     * @param trieurSubsystem       this command will run on
     * @param shooterSubsystem      the shooter subsystem
     * @param shooterCommand        the shooter command to run in parallel with
     */
    protected ShootRevolution(TrieurSubsystem trieurSubsystem, ShooterSubsystem shooterSubsystem, Command shooterCommand) {
        this.trieurSubsystem = trieurSubsystem;
        this.shooterSubsystem = shooterSubsystem;

        addCommands(
                shooterCommand,
                new OpenTrappe(trieurSubsystem),
                new WaitCommand(200),
                new MoulinRevolution(trieurSubsystem),
                new WaitCommand(100),
                new ParallelCommandGroup(
                        new CloseTrappe(trieurSubsystem),
                        new StopShooter(shooterSubsystem)));
    }

    @Override
    public void end(boolean interrupted) {
        // Call parent's end() to clean up any running sub-commands
        super.end(interrupted);

        // Clean trieur color
        trieurSubsystem.clearAllStoredColors();

        // If the command was cancelled (interrupted), perform cleanup
        if (interrupted) {
            // Turn off shooter and close trappe immediately
            shooterSubsystem.setVelocity(0);
            trieurSubsystem.closeTrappe();

            // The moulin will naturally stop at its current position
            // via the subsystem's periodic() method since it's running RUN_TO_POSITION
            // No additional command needed
        }
    }
}
