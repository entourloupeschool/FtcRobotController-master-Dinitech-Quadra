package org.firstinspires.ftc.teamcode.dinitech.commands.groups;

import com.arcrobotics.ftclib.command.Command;
import com.arcrobotics.ftclib.command.ParallelCommandGroup;
import com.arcrobotics.ftclib.command.SequentialCommandGroup;

import org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.trieur.ClearMoulinShootingPos;
import org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.trieur.MoulinToPosition;
import org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.trieur.OpenTrappe;
import org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.shooter.MaxSpeedShooter;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.ShooterSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.TrieurSubsystem;

public class ShootMoulinState extends SequentialCommandGroup {
    /**
     * Creates a ShootMoulinState Sequential Command Group
     * 
     * @param trieurSubsystem       this command will run on
     * @param shooterSubsystem      the shooter subsystem
     * @param moulinPositionToShoot the moulin position to shoot from
     */
    public ShootMoulinState(TrieurSubsystem trieurSubsystem, ShooterSubsystem shooterSubsystem,
            int moulinPositionToShoot) {
        this(trieurSubsystem, shooterSubsystem, moulinPositionToShoot, new MaxSpeedShooter(shooterSubsystem));
    }

    /**
     * Protected constructor for subclasses to provide custom shooter command
     * 
     * @param trieurSubsystem       this command will run on
     * @param shooterSubsystem      the shooter subsystem
     * @param moulinPositionToShoot the moulin position to shoot from
     * @param shooterCommand        the shooter command to run in parallel with
     *                              moulin positioning
     */
    protected ShootMoulinState(TrieurSubsystem trieurSubsystem, ShooterSubsystem shooterSubsystem,
            int moulinPositionToShoot, Command shooterCommand) {
        addCommands(
                new ParallelCommandGroup(
                        shooterCommand,
                        new MoulinToPosition(trieurSubsystem, moulinPositionToShoot, false)),
                new OpenTrappe(trieurSubsystem),
                new ClearMoulinShootingPos(trieurSubsystem, moulinPositionToShoot));
    }

}
