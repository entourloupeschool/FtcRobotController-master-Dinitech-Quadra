package org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.drive;

import com.arcrobotics.ftclib.command.CommandBase;

import org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.gamepad.Rumble;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.DriveSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.GamepadSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.VisionSubsystem;

/**
 * Default command that toggles between TeleDrive (normal) and TeleDriveLocked
 * (vision-assisted)
 * when the right bumper is pressed. This command manages the toggle state
 * persistently.
 */
public class ToggleSlowDrive extends CommandBase {
    private final DriveSubsystem driveSubsystem;
    private final GamepadSubsystem gamepadSubsystem;

    public ToggleSlowDrive(DriveSubsystem driveSubsystem,
            GamepadSubsystem gamepadSubsystem) {
        this.driveSubsystem = driveSubsystem;
        this.gamepadSubsystem = gamepadSubsystem;
    }

    @Override
    public void initialize() {
        driveSubsystem.getDefaultCommand().cancel();
        driveSubsystem.setIsATLocked(false);

        if (driveSubsystem.isSlowDrive()) {
            driveSubsystem.setDefaultCommand(new TeleDrive(driveSubsystem, gamepadSubsystem));
            driveSubsystem.setIsSlowDrive(false);

        } else {
            new Rumble(gamepadSubsystem, 3, 3).schedule();
            driveSubsystem.setDefaultCommand(new TeleSlowDrive(driveSubsystem, gamepadSubsystem));
            driveSubsystem.setIsSlowDrive(true);
        }

    }

    @Override
    public boolean isFinished() {
        // This command finishes immediately after scheduling the appropriate command
        return true;
    }

}