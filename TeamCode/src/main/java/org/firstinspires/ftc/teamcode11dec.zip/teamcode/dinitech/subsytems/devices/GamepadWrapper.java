package org.firstinspires.ftc.teamcode.dinitech.subsytems.devices;

import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.RUMBLE_POWER;

import com.arcrobotics.ftclib.command.button.Button;
import com.arcrobotics.ftclib.command.button.GamepadButton;
import com.arcrobotics.ftclib.command.button.Trigger;
import com.arcrobotics.ftclib.gamepad.GamepadEx;
import com.arcrobotics.ftclib.gamepad.GamepadKeys;
import com.qualcomm.robotcore.hardware.Gamepad;

/**
 * Wrapper class for GamepadEx that provides easy access to all buttons and triggers
 */
public class GamepadWrapper {
    private final GamepadEx gamepadEx;
    
    // D-pad buttons
    public final Button dpad_up;
    public final Button dpad_down;
    public final Button dpad_left;
    public final Button dpad_right;
    
    // Face buttons
    public final Button cross;      // A button
    public final Button circle;     // B button
    public final Button square;     // X button
    public final Button triangle;   // Y button
    
    // Bumpers
    public final Button bump_left;
    public final Button bump_right;
    
    // Triggers
//    public final Button trig_left;
//    public final Button trig_right;
    
    // Additional buttons
    public final Button start;
    public final Button back;
    public final Button left_stick_button;
    public final Button right_stick_button;
    public final Trigger psButton;
    public final Trigger touchpadButton;
    public final Button m1Button;
    public final Button m2Button;

    private final Gamepad.RumbleEffect rumbleEffectUp, rumbleEffectDown, rumbleEffectSimple, rumbleEffectW;
    
    /**
     * Create a GamepadWrapper for the given GamepadEx
     * @param gamepadEx The GamepadEx to wrap
     * @param r normalized red value from rgb
     * @param g normalized green value from rgb
     * @param b normalized blue value from rgb
     */
    public GamepadWrapper(GamepadEx gamepadEx, double r, double g, double b) {
        this.gamepadEx = gamepadEx;
        this.gamepadEx.gamepad.setLedColor(r, g, b, Gamepad.LED_DURATION_CONTINUOUS);

        // Initialize D-pad buttons
        dpad_up = new GamepadButton(gamepadEx, GamepadKeys.Button.DPAD_UP);
        dpad_down = new GamepadButton(gamepadEx, GamepadKeys.Button.DPAD_DOWN);
        dpad_left = new GamepadButton(gamepadEx, GamepadKeys.Button.DPAD_LEFT);
        dpad_right = new GamepadButton(gamepadEx, GamepadKeys.Button.DPAD_RIGHT);
        
        // Initialize face buttons
        cross = new GamepadButton(gamepadEx, GamepadKeys.Button.A);
        circle = new GamepadButton(gamepadEx, GamepadKeys.Button.B);
        square = new GamepadButton(gamepadEx, GamepadKeys.Button.X);
        triangle = new GamepadButton(gamepadEx, GamepadKeys.Button.Y);
        
        // Initialize bumpers
        bump_left = new GamepadButton(gamepadEx, GamepadKeys.Button.LEFT_BUMPER);
        bump_right = new GamepadButton(gamepadEx, GamepadKeys.Button.RIGHT_BUMPER);
        
        // Initialize triggers with threshold
//        trig_left = new Trigger(() -> gamepadEx.getTrigger(GamepadKeys.Trigger.LEFT_TRIGGER) > triggerThreshold);
//        trig_right = new Trigger(() -> gamepadEx.getTrigger(GamepadKeys.Trigger.RIGHT_TRIGGER) > triggerThreshold);
        
        // Initialize additional buttons
        start = new GamepadButton(gamepadEx, GamepadKeys.Button.START);
        back = new GamepadButton(gamepadEx, GamepadKeys.Button.BACK);
        left_stick_button = new GamepadButton(gamepadEx, GamepadKeys.Button.LEFT_STICK_BUTTON);
        right_stick_button = new GamepadButton(gamepadEx, GamepadKeys.Button.RIGHT_STICK_BUTTON);
        m1Button = new GamepadButton(gamepadEx, GamepadKeys.Button.B);
        m2Button = new GamepadButton(gamepadEx, GamepadKeys.Button.A);
        psButton = new Trigger(() -> gamepadEx.gamepad.ps);
        touchpadButton = new Trigger(() -> gamepadEx.gamepad.touchpad);

        rumbleEffectUp = new Gamepad.RumbleEffect.Builder()
                .addStep(RUMBLE_POWER/4, RUMBLE_POWER/4, 25)
                .addStep(0.0, 0.0, 5) 
                .addStep(RUMBLE_POWER/3, RUMBLE_POWER/3, 25)  
                .addStep(0.0, 0.0, 5)  
                .addStep(RUMBLE_POWER/2, RUMBLE_POWER/2, 25)  
                .addStep(0.0, 0.0, 5)  
                .addStep(RUMBLE_POWER, RUMBLE_POWER, 100)  
                .build();

        rumbleEffectDown = new Gamepad.RumbleEffect.Builder()
                .addStep(RUMBLE_POWER, RUMBLE_POWER, 50) 
                .addStep(0.0, 0.0, 5) 
                .addStep(RUMBLE_POWER/2, RUMBLE_POWER/2, 25)  
                .addStep(0.0, 0.0, 5)  
                .addStep(RUMBLE_POWER/3, RUMBLE_POWER/3, 25)  
                .addStep(0.0, 0.0, 5)  
                .addStep(RUMBLE_POWER/4, RUMBLE_POWER/4, 25)  
                .addStep(0.0, 0.0, 5)
                .build();

        rumbleEffectSimple = new Gamepad.RumbleEffect.Builder()
                .addStep(RUMBLE_POWER, RUMBLE_POWER, 100)  //  Rumble both motor 100% for 100 mSec
                .build();

        rumbleEffectW = new Gamepad.RumbleEffect.Builder()
                .addStep(RUMBLE_POWER, RUMBLE_POWER, 50)
                .addStep(0.0, 0.0, 25) 
                .addStep(RUMBLE_POWER, RUMBLE_POWER, 100)  
                .addStep(0.0, 0.0, 25)  
                .addStep(RUMBLE_POWER, RUMBLE_POWER, 100)  
                .addStep(0.0, 0.0, 25)  
                .addStep(RUMBLE_POWER, RUMBLE_POWER, 50)  
                .build();
                
    }

    /**
     * Get the underlying GamepadEx object for direct access if needed
     * @return The wrapped GamepadEx
     */
    public GamepadEx getGamepadEx() {
        return gamepadEx;
    }
    
    /**
     * Get left stick X value
     * @return Left stick X value (-1.0 to 1.0)
     */
    public double getLeftX() {
        return gamepadEx.getLeftX();
    }
    
    /**
     * Get left stick Y value
     * @return Left stick Y value (-1.0 to 1.0)
     */
    public double getLeftY() {
        return gamepadEx.getLeftY();
    }
    
    /**
     * Get right stick X value
     * @return Right stick X value (-1.0 to 1.0)
     */
    public double getRightX() {
        return gamepadEx.getRightX();
    }
    
    /**
     * Get right stick Y value
     * @return Right stick Y value (-1.0 to 1.0)
     */
    public double getRightY() {
        return gamepadEx.getRightY();
    }
    
    /**
     * Get left trigger value
     * @return Left trigger value (0.0 to 1.0)
     */
    public double getLeftTriggerValue() {
        return gamepadEx.getTrigger(GamepadKeys.Trigger.LEFT_TRIGGER);
    }
    
    /**
     * Get right trigger value
     * @return Right trigger value (0.0 to 1.0)
     */
    public double getRightTriggerValue() {
        return gamepadEx.getTrigger(GamepadKeys.Trigger.RIGHT_TRIGGER);
    }

    /**
     * Get touchpad finger 1 X position
     * @return Touchpad finger 1 X position (-1.0 to 1.0)
     */
    public double getTouchpadFinger1X() {
        return gamepadEx.gamepad.touchpad_finger_1_x;
    }

    /**
     * Get touchpad finger 1 Y position
     * @return Touchpad finger 1 Y position (-1.0 to 1.0)
     */
    public double getTouchpadFinger1Y() {
        return gamepadEx.gamepad.touchpad_finger_1_y;
    }

        /**
     * Get touchpad finger 2 X position
     * @return Touchpad finger 2 X position (-1.0 to 1.0)
     */
    public double getTouchpadFinger2X() {
        return gamepadEx.gamepad.touchpad_finger_2_x;
    }

    /**
     * Get touchpad finger 2 Y position
     * @return Touchpad finger 2 Y position (-1.0 to 1.0)
     */
    public double getTouchpadFinger2Y() {
        return gamepadEx.gamepad.touchpad_finger_2_y;
    }

    public void rumble(int rumbleEffectNumber){
        switch(rumbleEffectNumber){
            case 1:
                gamepadEx.gamepad.runRumbleEffect(rumbleEffectUp);
                break;
            case 2:
                gamepadEx.gamepad.runRumbleEffect(rumbleEffectDown);
                break;
            case 3:
                gamepadEx.gamepad.runRumbleEffect(rumbleEffectSimple);
                break;
            case 4:
                gamepadEx.gamepad.runRumbleEffect(rumbleEffectW);
                break;
        }
    }

    public void runCustomRumble(Gamepad.RumbleEffect customRumbleEffect){
        gamepadEx.gamepad.runRumbleEffect(customRumbleEffect);
    }
}
