package org.firstinspires.ftc.teamcode.dinitech.commands.groups;

import com.arcrobotics.ftclib.command.ConditionalCommand;

import org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.gamepad.Rumble;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.GamepadSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.ShooterSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.TrieurSubsystem;

public class ShootColor extends ConditionalCommand {

    /**
     * Creates a ShootColor Conditional Command
     * 
     * @param trieurSubsystem  this command will run on
     * @param shooterSubsystem
     * @param gamepadSubsystem
     * @param inputColor       the color to shoot
     */
    public ShootColor(TrieurSubsystem trieurSubsystem, ShooterSubsystem shooterSubsystem,
            GamepadSubsystem gamepadSubsystem, TrieurSubsystem.ArtifactColor inputColor) {
        super(
                // Command to execute when condition is true (artifact of specified color found)
                new ShootMoulinState(trieurSubsystem, shooterSubsystem,
                        trieurSubsystem.getClosestShootingPositionForColor(inputColor)),
                // Command to execute when condition is false (no artifact of specified color)
                new Rumble(gamepadSubsystem, 3, 1),
                // Condition to evaluate
                () -> trieurSubsystem.getClosestShootingPositionForColor(inputColor) > 0);
    }
}
