package org.firstinspires.ftc.teamcode.dinitech.commands.groups;

import com.arcrobotics.ftclib.command.ConditionalCommand;
import com.arcrobotics.ftclib.command.SequentialCommandGroup;

import org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.gamepad.Rumble;
import org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.trieur.MoulinNextNext;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.ChargeurSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.GamepadSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.TrieurSubsystem;

public class ArtefactPickAway extends SequentialCommandGroup {
    /**
     * Creates a ShootGreen Sequential Command Group
     * 
     * @param trieurSubsystem  this command will run on
     * @param gamepadSubsystem
     */

    public ArtefactPickAway(TrieurSubsystem trieurSubsystem,
            GamepadSubsystem gamepadSubsystem) {
        addCommands(
                new DetectArtefact(trieurSubsystem, gamepadSubsystem),
                new ConditionalCommand(
                        new MoulinNextNext(trieurSubsystem),
                        new Rumble(gamepadSubsystem, 3, 1),
                        trieurSubsystem::hasNewRegister));
    }
}
