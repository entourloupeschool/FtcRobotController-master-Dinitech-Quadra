package org.firstinspires.ftc.teamcode.dinitech.subsytems.devices;

import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.CS1_NAME;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.CS2_NAME;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.CS3_NAME;

import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.NormalizedColorSensor;

public class TripleColorSensors {

    // Color Sensors avec moyennes intégrées
    public final AveragingColorSensor colorSensor1;
    public final AveragingColorSensor colorSensor2;
    public final AveragingColorSensor colorSensor3;

    public TripleColorSensors(HardwareMap hardwareMap) {
        this.colorSensor1 = new AveragingColorSensor(hardwareMap.get(NormalizedColorSensor.class, CS1_NAME));
        this.colorSensor2 = new AveragingColorSensor(hardwareMap.get(NormalizedColorSensor.class, CS2_NAME));
        this.colorSensor3 = new AveragingColorSensor(hardwareMap.get(NormalizedColorSensor.class, CS3_NAME));

    }

    public void updateAllSensors() {
        colorSensor1.update();
        colorSensor2.update();
        colorSensor3.update();
    }

    public void updateSensor(int sensorNumber) {
        switch (sensorNumber) {
            case 1:
                colorSensor1.update();
            case 2:
                colorSensor2.update();
            case 3:
                colorSensor3.update();
        }
    }

    public void clearSamplesAllSensors() {
        colorSensor1.clearSamples();
        colorSensor2.clearSamples();
        colorSensor3.clearSamples();
    }

    public void clearSensor(int sensorNumber) {
        switch (sensorNumber) {
            case 1:
                colorSensor1.clearSamples();
            case 2:
                colorSensor2.clearSamples();
            case 3:
                colorSensor3.clearSamples();
        }
    }

    public boolean isGreen(int sensorNumber) {
        switch (sensorNumber) {
            case 1:
                return colorSensor1.isGreen();
            case 2:
                return colorSensor2.isGreen();
            case 3:
                return colorSensor3.isGreen();
            default:
                return false;
        }
    }

    public boolean isPurple(int sensorNumber) {
        switch (sensorNumber) {
            case 1:
                return colorSensor1.isPurple();
            case 2:
                return colorSensor2.isPurple();
            case 3:
                return colorSensor3.isPurple();
            default:
                return false;
        }
    }

    public boolean isNeither(int sensorNumber) {
        switch (sensorNumber) {
            case 1:
                boolean notGreen1 = !colorSensor1.isGreen();
                boolean notPurple1 = !colorSensor1.isPurple();
                return notGreen1 && notPurple1;
            case 2:
                boolean notGreen2 = !colorSensor2.isGreen();
                boolean notPurple2 = !colorSensor2.isPurple();
                return notGreen2 && notPurple2;
            case 3:
                boolean notGreen3 = !colorSensor3.isGreen();
                boolean notPurple3 = !colorSensor3.isPurple();
                return notGreen3 && notPurple3;
            default:
                return false;
        }
    }

    public boolean isBothGreen() {
        return colorSensor1.isGreen() && colorSensor2.isGreen();
    }

    public boolean isBothPurple() {
        return colorSensor1.isPurple() && colorSensor2.isPurple();
    }

    public double getDistance(int sensorNumber) {
        switch (sensorNumber) {
            case 1:
                return colorSensor1.getDistance();
            case 2:
                return colorSensor2.getDistance();
            case 3:
                return colorSensor3.getDistance();
            default:
                return 0;
        }
    }

    public boolean isDistanceLower(int sensorNumber, double distanceCM) {
        switch (sensorNumber) {
            case 1:
                return colorSensor1.getDistance() < distanceCM;
            case 2:
                return colorSensor2.getDistance() < distanceCM;
            case 3:
                return colorSensor3.getDistance() < distanceCM;
            case 4:
                return colorSensor1.getDistance() < distanceCM && colorSensor2.getDistance() < distanceCM;
            default:
                return false;
        }
    }

    public boolean isDistanceBetween(int sensorNumber, double distanceCM, double margin) {
        double distance1;
        double distance2;
        double distance3;
        switch (sensorNumber) {
            case 1:
                distance1 = colorSensor1.getDistance();
                return distance1 > distanceCM - margin && distance1 < distanceCM + margin;
            case 2:
                distance2 = colorSensor2.getDistance();
                return distance2 > distanceCM - margin && distance2 < distanceCM + margin;
            case 3:
                distance3 = colorSensor3.getDistance();
                return distance3 > distanceCM - margin && distance3 < distanceCM + margin;
            case 4:
                distance1 = colorSensor1.getDistance();
                distance2 = colorSensor2.getDistance();
                return distance1 > distanceCM - margin && distance1 < distanceCM + margin
                        && distance2 > distanceCM - margin && distance2 < distanceCM + margin;
            default:
                return false;
        }
    }

    public int getSampleCount(int sensorNumber) {
        switch (sensorNumber) {
            case 1:
                return colorSensor1.getSampleCount();
            case 2:
                return colorSensor2.getSampleCount();
            case 3:
                return colorSensor3.getSampleCount();
            default:
                return 0;
        }
    }
}
