package org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.trieur;

import org.firstinspires.ftc.teamcode.dinitech.subsytems.TrieurSubsystem;

public class MoulinPrevious extends MoulinToPosition {
    private final TrieurSubsystem trieurSubsystem;

    /**
     * Creates a new MoulinNext command that moves to the next moulin position and waits for completion.
     * @param trieurSubsystem the subsystem used by this command
     */
    public MoulinPrevious(TrieurSubsystem trieurSubsystem){
        // Pass dummy values to super() - we'll set the real target in initialize()
        super(trieurSubsystem, 0, true);
        this.trieurSubsystem = trieurSubsystem;
    }

    @Override
    public void initialize() {
        // Calculate the next position when the button is actually pressed
        moulinTargetPosition = trieurSubsystem.getNPreviousMoulinPosition(trieurSubsystem.getMoulinPosition(), 1);
        makeShort = true;

        // Call parent's initialize() to start the movement
        super.initialize();
    }
}
