package org.firstinspires.ftc.teamcode.dinitech.subsytems;

import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.MAX_SHOOT_SPEED;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.SHOOTER_MOTOR_NAME;

import com.arcrobotics.ftclib.command.SubsystemBase;
import com.arcrobotics.ftclib.hardware.motors.MotorEx;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.PIDFCoefficients;

import org.firstinspires.ftc.robotcore.external.Telemetry;

public class ShooterSubsystem extends SubsystemBase {
    private final DcMotorEx dcMotorEx;
    private final Telemetry telemetry;
    private final DcMotor.RunMode runMode = DcMotor.RunMode.RUN_USING_ENCODER;

    private final double pInit = 0.1;
    private final double iInit = 0.0002;
    private final double dInit = 0.0;
    private final double fInit = 0.0075;


    public ShooterSubsystem(HardwareMap hardwareMap, Telemetry telemetry) {
        dcMotorEx = hardwareMap.get(DcMotorEx.class, SHOOTER_MOTOR_NAME);
        dcMotorEx.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.FLOAT);
        dcMotorEx.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        dcMotorEx.setMode(runMode);
        dcMotorEx.setVelocityPIDFCoefficients(pInit, iInit, dInit, fInit);

        this.telemetry = telemetry;
    }

    public int getPosition() {
        return dcMotorEx.getCurrentPosition();
    }

    public void setVelocity(double velocity) {
        dcMotorEx.setVelocity(velocity);
    }

    public double getVelocity() {
        return dcMotorEx.getVelocity();
    }

    public void setPower(double power){
            dcMotorEx.setPower(power);
    }

    public double getPower() {
        return dcMotorEx.getPower();
    }

    public boolean isPowered() {
        return getPower() > 0;
    }

    public void incrementVelocity(double velocityIncrement) {
        double newVelocity = getVelocity() + velocityIncrement;
        if (newVelocity <= MAX_SHOOT_SPEED && newVelocity >= 0) {
            setVelocity(newVelocity);
        }
    }

    public void incrementPower(double powerIncrement) {
        double newPower = getPower() + powerIncrement;
        if (newPower <= 1 && newPower >= 0) {
            setPower(newPower);
        }
    }

    public boolean isSpeedSuperiorOrEqual(double speed) {
        return getVelocity() >= speed;
    }

    public boolean isSpeedEqual(double speed) {
        return getVelocity() == speed;
    }

    public boolean isSpeedAround(double speed, double margin) {
        return Math.abs(getVelocity() - speed) <= margin;
    }

    public boolean isOverCurrent() {
        return dcMotorEx.isOverCurrent();
    }

    public boolean isBusy(){
        return dcMotorEx.isBusy();
    }

    public void setPIDFVelocity(double p, double i, double d, double f){
        dcMotorEx.setVelocityPIDFCoefficients(p, i, d, f);
    }

    public PIDFCoefficients getPIDFVelocity(){
        return dcMotorEx.getPIDFCoefficients(runMode);
    }

    public void stopMotor() {
        dcMotorEx.setPower(0);
    }

    @Override
    public void periodic() {
        if (isOverCurrent()) {
            setVelocity(0);
        }
        printShooterTelemetry(telemetry);
    }

    /**
     * telemetry Trappe to draw on driverHub
     */
    private void printShooterTelemetry(final Telemetry telemetry) {
        telemetry.addData("shooter speed (ticks/s) :", getVelocity());
        telemetry.addData("shooter power", getPower());
        telemetry.addData("isBusy", isBusy());
        // telemetry.addData("shooter ticks :", getPosition());

    }
}
