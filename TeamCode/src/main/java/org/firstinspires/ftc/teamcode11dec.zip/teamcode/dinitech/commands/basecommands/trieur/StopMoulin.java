package org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.trieur;

import com.arcrobotics.ftclib.command.CommandBase;

import org.firstinspires.ftc.teamcode.dinitech.subsytems.TrieurSubsystem;

public class StopMoulin extends CommandBase {
    private final TrieurSubsystem trieurSubsystem;
    /**
     * Creates a new MoulinRotateHoraire command.
     * @param trieurSubsystem the subsystem used by this command
     */
    public StopMoulin(TrieurSubsystem trieurSubsystem){
        this.trieurSubsystem = trieurSubsystem;
        addRequirements(trieurSubsystem);
    }

    @Override
    public void initialize(){
        trieurSubsystem.setMoulinPower(0);
    }

    @Override
    public boolean isFinished() {
        return true;
    }

    @Override
    public void end(boolean interrupted){
        if (interrupted){
            trieurSubsystem.resetTargetMoulinMotor();
        }
    }
}
