package org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.drive;

import com.arcrobotics.ftclib.command.CommandBase;

import org.firstinspires.ftc.teamcode.dinitech.subsytems.DriveSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.GamepadSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.devices.GamepadWrapper;

public class TeleSlowDrive extends CommandBase {
    private final DriveSubsystem driveSubsystem;
    private final GamepadWrapper driver;

    public TeleSlowDrive(DriveSubsystem driveSubsystem, GamepadSubsystem gamepadSubsystem) {
        this.driveSubsystem = driveSubsystem;
        driver = gamepadSubsystem.driver;

        addRequirements(driveSubsystem);
    }

    @Override
    public void execute(){
        // Normal manual driving
        driveSubsystem.teleSlowDrive(driver.getLeftX(), driver.getLeftY(),driver.getRightX(), driver.getRightTriggerValue());
    }
}