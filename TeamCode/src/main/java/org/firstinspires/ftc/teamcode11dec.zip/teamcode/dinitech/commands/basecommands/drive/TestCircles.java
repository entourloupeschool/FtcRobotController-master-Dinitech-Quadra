package org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.drive;

import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.BACKWARD_CIRCLE_CENTER_POSE;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.FORWARD_CIRCLE_CENTER_POSE;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.LEFT_CIRCLE_CENTER_POSE;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.RIGHT_CIRCLE_CENTER_POSE;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.TEST_CIRCLE_RADIUS;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.TEST_CONSTRAINTS;

import com.acmerobotics.roadrunner.Pose2d;
import com.acmerobotics.roadrunner.Vector2d;

import org.firstinspires.ftc.teamcode.dinitech.subsytems.DriveSubsystem;

public class TestCircles extends FollowTrajectory {
    public TestCircles(DriveSubsystem driveSubsystem){
        super(
                driveSubsystem.dinitechMecanumDrive.actionBuilder(driveSubsystem.getPose(), TEST_CONSTRAINTS)
                        // Left circle
                        .splineToLinearHeading(LEFT_CIRCLE_CENTER_POSE.times(new Pose2d(new Vector2d(TEST_CIRCLE_RADIUS,0), -Math.PI/2)), Math.PI/2)
                        .splineToLinearHeading(LEFT_CIRCLE_CENTER_POSE.times(new Pose2d(new Vector2d(0,TEST_CIRCLE_RADIUS), -Math.PI)), Math.PI)
                        .splineToLinearHeading(LEFT_CIRCLE_CENTER_POSE.times(new Pose2d(new Vector2d(-TEST_CIRCLE_RADIUS,0), Math.PI/2)), -Math.PI/2)
                        .splineToLinearHeading(LEFT_CIRCLE_CENTER_POSE.times(new Pose2d(new Vector2d(0,-TEST_CIRCLE_RADIUS), 0)), 0)

                        // right circle
                        .splineToLinearHeading(RIGHT_CIRCLE_CENTER_POSE.times(new Pose2d(new Vector2d(TEST_CIRCLE_RADIUS,0), Math.PI/2)), -Math.PI/2)
                        .splineToLinearHeading(RIGHT_CIRCLE_CENTER_POSE.times(new Pose2d(new Vector2d(0,-TEST_CIRCLE_RADIUS), Math.PI)), Math.PI)
                        .splineToLinearHeading(RIGHT_CIRCLE_CENTER_POSE.times(new Pose2d(new Vector2d(-TEST_CIRCLE_RADIUS,0), -Math.PI/2)), Math.PI/2)
                        .splineToLinearHeading(RIGHT_CIRCLE_CENTER_POSE.times(new Pose2d(new Vector2d(0,TEST_CIRCLE_RADIUS), 0)), 0)

                        .setTangent(-Math.PI/2)
                        // forward circle
                        .splineToLinearHeading(FORWARD_CIRCLE_CENTER_POSE.times(new Pose2d(new Vector2d(0,-TEST_CIRCLE_RADIUS), -Math.PI/2)), 0)
                        .splineToLinearHeading(FORWARD_CIRCLE_CENTER_POSE.times(new Pose2d(new Vector2d(TEST_CIRCLE_RADIUS,0), -Math.PI)), Math.PI/2)
                        .splineToLinearHeading(FORWARD_CIRCLE_CENTER_POSE.times(new Pose2d(new Vector2d(0,TEST_CIRCLE_RADIUS), Math.PI/2)), -Math.PI)
                        .splineToLinearHeading(FORWARD_CIRCLE_CENTER_POSE.times(new Pose2d(new Vector2d(-TEST_CIRCLE_RADIUS,0), 0)), -Math.PI/2)

                        // backward circle
                        .splineToLinearHeading(BACKWARD_CIRCLE_CENTER_POSE.times(new Pose2d(new Vector2d(0, -TEST_CIRCLE_RADIUS), Math.PI/2)), -Math.PI)
                        .splineToLinearHeading(BACKWARD_CIRCLE_CENTER_POSE.times(new Pose2d(new Vector2d(-TEST_CIRCLE_RADIUS,0), -Math.PI)), Math.PI/2)
                        .splineToLinearHeading(BACKWARD_CIRCLE_CENTER_POSE.times(new Pose2d(new Vector2d(0, TEST_CIRCLE_RADIUS), -Math.PI/2)), 0)
                        .splineToLinearHeading(BACKWARD_CIRCLE_CENTER_POSE.times(new Pose2d(new Vector2d(TEST_CIRCLE_RADIUS,0), 0)), -Math.PI/2)

                        .build(), driveSubsystem.getDriveSubsystemSet()
        );
    }

}
