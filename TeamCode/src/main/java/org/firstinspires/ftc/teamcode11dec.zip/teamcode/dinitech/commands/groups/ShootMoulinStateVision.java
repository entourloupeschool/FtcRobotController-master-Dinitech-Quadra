package org.firstinspires.ftc.teamcode.dinitech.commands.groups;

import org.firstinspires.ftc.teamcode.dinitech.subsytems.ShooterSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.TrieurSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.VisionSubsystem;

public class ShootMoulinStateVision extends ShootMoulinState {
    /**
     * Creates a ShootMoulinStateWithVision that uses vision-based shooter speed
     * 
     * @param trieurSubsystem       this command will run on
     * @param shooterSubsystem      the shooter subsystem
     * @param visionSubsystem       the vision subsystem for determining shooter
     *                              speed
     * @param moulinPositionToShoot the moulin position to shoot from
     */
    public ShootMoulinStateVision(TrieurSubsystem trieurSubsystem, ShooterSubsystem shooterSubsystem,
                                  VisionSubsystem visionSubsystem, int moulinPositionToShoot) {
        super(trieurSubsystem, shooterSubsystem, moulinPositionToShoot,
                new VisionShooter(shooterSubsystem, visionSubsystem, false));
    }
}
