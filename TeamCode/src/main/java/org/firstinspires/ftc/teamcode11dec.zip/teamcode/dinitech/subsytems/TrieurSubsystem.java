package org.firstinspires.ftc.teamcode.dinitech.subsytems;

import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.DISTANCE_ARTEFACT_IN_TRIEUR;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.DISTANCE_MARGIN_ARTEFACT_IN_TRIEUR;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.INTERVALLE_TICKS_MOULIN;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.MAGNETIC_ON_MOULIN_POSITION;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.OFFSET_MAGNETIC_POS;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.POWER_MOULIN_ROTATION;

import com.arcrobotics.ftclib.command.SubsystemBase;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.PIDFCoefficients;

import org.firstinspires.ftc.robotcore.external.Telemetry;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.devices.TripleColorSensors;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.devices.MagneticSwitch;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.devices.Trappe;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.devices.Moulin;

import java.util.Arrays;

public class TrieurSubsystem extends SubsystemBase {
    public enum ArtifactColor {
        NONE,
        GREEN,
        PURPLE,
        UNKNOWN
    }

    private final Trappe trappe;
    private final Moulin moulin;
    private final TripleColorSensors tripleColorSensors;
    private final MagneticSwitch magneticSwitch;
    private final Telemetry telemetry;

    // Array to track what color is stored at each moulin pos (1-6)
    // Index 0 = pos 1, Index 1 = pos 2, etc.
    private final ArtifactColor[] moulinStoragePositionColors = new ArtifactColor[3];

    // Track the last detected color for artifact pickup
    private ArtifactColor lastDetectedColor = ArtifactColor.NONE;

    private boolean newRegister = false;
    private boolean newColoredRegister = false;
    private boolean isFull = false;
    private boolean wentRecalibrationOpposite = true;

    /**
     * Construct the TrieurSubsystem.
     * 
     * @param hardwareMap HardwareMap for device initialization
     * @param telemetry   Telemetry object for reporting
     */
    public TrieurSubsystem(HardwareMap hardwareMap, final Telemetry telemetry) {
        trappe = new Trappe(hardwareMap);
        moulin = new Moulin(hardwareMap);
        tripleColorSensors = new TripleColorSensors(hardwareMap);
        magneticSwitch = new MagneticSwitch(hardwareMap);

        this.telemetry = telemetry;

        // Initialize all moulin pos as empty
        clearAllStoredColors();

        // recalibrate on init
        setWentRecalibrationOpposite(true);
    }

    public void rotateToMoulinPosition(int pos, boolean makeShort) {
        moulin.setMoulinPosition(pos, makeShort);
    }

    public int getMoulinPosition() {
        return moulin.getPosition();
    }

    public int getMoulinMotorPosition() {
        return moulin.getMotorPosition();
    }

    public int getMoulinMotorTargetPosition() {
        return moulin.getTargetPosition();
    }

    public int getMoulinMotorRemainingDistance() {
        return moulin.getRemainingDistance();
    }

    public void resetTargetMoulinMotor() {
        setMoulinTargetPosition(getMoulinMotorPosition());
    }

    public void setMoulinPower(double power) {
        moulin.setPower(power);
    }

    public void incrementMoulinTargetPosition(double incr) {
        moulin.incrementTargetPosition(incr);
    }

    public void setMoulinTargetPosition(int targetPosition) {
        moulin.setTargetPositionMotor(targetPosition);
    }

    public boolean shouldMoulinStopPower() {
        return moulin.shouldStopPower();
    }

    public int getNNextMoulinPosition(int pos, int n) {
        return Moulin.getNNextPosition(pos, n);
    }

    public int getNPreviousMoulinPosition(int pos, int n) {
        return Moulin.getNPreviousPosition(pos, n);
    }

    /**
     * Check if an artifact is sufficiently close to the moulin for safe rotation
     * Uses both color sensors to detect proximity
     * 
     * @return true if artifact is in position for pickup
     */
    public boolean isArtefactInTrieur() {
        return tripleColorSensors.isDistanceBetween(1, DISTANCE_ARTEFACT_IN_TRIEUR, DISTANCE_MARGIN_ARTEFACT_IN_TRIEUR)
                || tripleColorSensors.isDistanceBetween(2, DISTANCE_ARTEFACT_IN_TRIEUR,
                        DISTANCE_MARGIN_ARTEFACT_IN_TRIEUR);
    }

    public void updateColorSensors() {
        tripleColorSensors.updateAllSensors();
    }

    public void clearSamplesColorSensors() {
        tripleColorSensors.clearSamplesAllSensors();
    }

    /**
     * Get sample count for color sensor averaging
     */
    public int getColorSensorSampleCount() {
        return tripleColorSensors.getSampleCount(1);
    }

    /**
     * Detect and store the color of an artifact being picked up
     * Should be called when isBallInTrieur() returns true
     * Cache is automatically updated by setMoulinPositionColor()
     */
    public void registerArtefact() {
        ArtifactColor detectedColor = detectBottomArtifactColor();

        int moulinCurrentPos = getMoulinPosition();
        int bottomStoragePos = Moulin.getMoulinStoragePos(moulinCurrentPos);

        // Store the color at the current moulin storage Pos
        setMoulinStoragePositionColor(bottomStoragePos, detectedColor);

        if (detectedColor == ArtifactColor.GREEN || detectedColor == ArtifactColor.PURPLE) {
            setNewcoloredRegister(true);
        }
        setNewRegister(true);

        if (howManyArtifacts() == 3) {
            setIsFull(true);
        }
        // } else {
        // ArtifactColor monoArtifactColor = hardDetectMonoArtifactColor();
        //
        // if (monoArtifactColor != ArtifactColor.UNKNOWN){
        // int monoStoragePos =
        // Moulin.getMoulinStoragePos(Moulin.getNPreviousPosition(moulinCurrentPos, 2));
        // setMoulinStoragePositionColor(monoStoragePos, monoArtifactColor);
        // }
        // }

        lastDetectedColor = detectedColor;
    }

    /**
     * Detect the color of the artifact at the pickup position
     * 
     * @return The detected artifact color
     */
    private ArtifactColor detectBottomArtifactColor() {
        // Cache sensor values to avoid repeated I/O
        boolean cs1Purple = tripleColorSensors.isPurple(1);
        boolean cs1Neither = tripleColorSensors.isNeither(1);

        boolean cs2Purple = tripleColorSensors.isPurple(2);
        boolean cs2Neither = tripleColorSensors.isNeither(2);

        if ((cs1Purple && cs2Purple) || (cs1Purple && cs2Neither) || (cs2Purple && cs1Neither)) {
            return ArtifactColor.PURPLE;
        }

        return ArtifactColor.GREEN;
    }

    /**
     * Detect the color of the artifact at the pickup position
     *
     * @return The detected artifact color
     */
    private ArtifactColor hardDetectBottomArtifactColor() {
        // Cache sensor values to avoid repeated I/O
        boolean cs1Green = tripleColorSensors.isGreen(1);
        boolean cs1Purple = tripleColorSensors.isPurple(1);
        boolean cs1Neither = tripleColorSensors.isNeither(1);

        boolean cs2Green = tripleColorSensors.isGreen(2);
        boolean cs2Purple = tripleColorSensors.isPurple(2);
        boolean cs2Neither = tripleColorSensors.isNeither(2);

        if ((cs1Green && cs2Green) || (cs1Green && cs2Neither) || (cs2Green &&
                cs1Neither)) {
            return ArtifactColor.GREEN;
        } else if ((cs1Purple && cs2Purple) || (cs1Purple && cs2Neither) ||
                (cs2Purple && cs1Neither)) {
            return ArtifactColor.PURPLE;
        }
        return ArtifactColor.UNKNOWN;
    }

    /**
     * Detect the color of the artifact at the mono position
     *
     * @return The detected artifact color
     */
    private ArtifactColor hardDetectMonoArtifactColor() {
        if (tripleColorSensors.isPurple(3)) {
            return ArtifactColor.PURPLE;
        } else if (tripleColorSensors.isGreen(3)) {
            return ArtifactColor.GREEN;
        } else {
            return ArtifactColor.UNKNOWN;
        }
    }

    /**
     * Can be called only if:
     * - registerArtefact() is not allready called
     * - is on storagePosition
     */
    private void updateKnowledgeColors() {
        // // Bottom detectors
        // ArtifactColor bottomDetectorColor = hardDetectBottomArtifactColor();
        //
        // if (bottomDetectorColor != ArtifactColor.UNKNOWN){
        // setMoulinStoragePositionColor(moulin.getCurrentStoragePosition(),
        // bottomDetectorColor);
        // }
        //
        // lastDetectedColor = bottomDetectorColor;
    }

    /**
     * Set the color associated with a specific moulin storage position
     * 
     * @param pos   Moulin storage position (1-3)
     * @param color Artifact color to associate
     */
    public void setMoulinStoragePositionColor(int pos, ArtifactColor color) {
        moulinStoragePositionColors[pos - 1] = color;
    }

    /**
     * Get the color associated with a specific moulin storage position
     * 
     * @param pos Moulin storage position (1-3)
     * @return The artifact color at that pos
     */
    public ArtifactColor getMoulinStoragePositionColor(int pos) {
        return moulinStoragePositionColors[pos - 1];
    }

    /**
     * Clear the color association when an artifact is shot
     * 
     * @param pos Moulin position that was shot from
     */
    public void clearMoulinStoragePositionColor(int pos) {
        if (!Moulin.isStoragePosition(pos)) {
            throw new IllegalArgumentException("Invalid storage pos: " + pos);
        }
        setMoulinStoragePositionColor(pos, ArtifactColor.NONE);

        setIsFull(false);
    }

    /**
     * Clear all stored artifact colors (reset moulin to empty)
     */
    public void clearAllStoredColors() {
        Arrays.fill(moulinStoragePositionColors, ArtifactColor.NONE);
        setIsFull(false);
    }

    /**
     * Get the last detected artifact color
     * 
     * @return The color of the last detected artifact
     */
    public ArtifactColor getLastDetectedColor() {
        return lastDetectedColor;
    }

    /**
     * Get all moulin storage positions that contain artifacts of a specific color
     * 
     * @param color The color to search for
     * @return Array of moulin storage positions containing that color
     */
    public int[] getPosWithColor(ArtifactColor color) {
        int count = 0;
        int[] tempPos = new int[3];

        for (int i = 0; i < moulinStoragePositionColors.length; i++) {
            if (moulinStoragePositionColors[i] == color) {
                // Convert storage index (0-2) to Moulin position (1, 3, 5)
                // Index 0 -> Pos 1, Index 1 -> Pos 3, Index 2 -> Pos 5
                tempPos[count] = (i * 2) + 1;
                count++;
            }
        }

        // Create result array with exact size
        int[] result = new int[count];
        System.arraycopy(tempPos, 0, result, 0, count);
        return result;
    }

    public boolean wentRecalibrationOpposite() {
        return wentRecalibrationOpposite;
    }

    public void setWentRecalibrationOpposite(boolean wentRecalibrationOpposite) {
        this.wentRecalibrationOpposite = wentRecalibrationOpposite;
    }

    /**
     * Get the shooting position for a specific color
     * 
     * @param color The color to find shooting position for
     * @return Shooting position pos, or -1 if no artifacts of that color
     */
    public int getClosestShootingPositionForColor(ArtifactColor color) {
        int[] posWithColor;
        switch (color) {
            case PURPLE:
                posWithColor = getPosWithColor(ArtifactColor.PURPLE);
                break;
            case GREEN:
                posWithColor = getPosWithColor(ArtifactColor.GREEN);
                break;
            case UNKNOWN:
                posWithColor = getPosWithColor(ArtifactColor.UNKNOWN);
                break;
            default:
                // For NONE or unexpected values, return empty array
                posWithColor = new int[0];
                break;
        }

        // Transform storage positions to shooting positions
        for (int i = 0; i < posWithColor.length; i++) {
            posWithColor[i] = Moulin.getOppositePosition(posWithColor[i]);
        }

        // If pos with Color is not empty, get the closest pos to the current pos
        if (posWithColor.length > 0) {
            return Moulin.getClosestPositionToShoot(posWithColor);
        }
        return -1;
    }

    public int getClosestShootingPositionAnyColor() {
        int[] anyColorPositions = new int[3];
        // Get all the possible shooting positions
        int greenShootingPosition = getClosestShootingPositionForColor(TrieurSubsystem.ArtifactColor.GREEN);
        int purpleShootingPosition = getClosestShootingPositionForColor(TrieurSubsystem.ArtifactColor.PURPLE);
        int unknownShootingPosition = getClosestShootingPositionForColor(TrieurSubsystem.ArtifactColor.UNKNOWN);

        if (greenShootingPosition != -1) {
            anyColorPositions[0] = greenShootingPosition;
        }
        if (purpleShootingPosition != -1) {
            anyColorPositions[1] = purpleShootingPosition;
        }
        if (unknownShootingPosition != -1) {
            anyColorPositions[2] = unknownShootingPosition;
        }

        return Moulin.getClosestPositionToShoot(anyColorPositions);
    }

    public boolean isMoulinOverCurrent() {
        return moulin.isOverCurrent();
    }

    public void closeTrappe() {
        trappe.close();
    }

    public void openTrappe() {
        trappe.open();
    }

    public void toggleTrappe() {
        trappe.toggleTrappe();
    }

    public void incrOpenTrappe() {
        trappe.incrementalRotationUp();
    }

    public void incrCloseTrappe() {
        trappe.incrementalRotationDown();
    }

    public boolean isMagneticSwitch() {
        return magneticSwitch.isMagnetic();
    }

    public void setNewRegister(boolean register) {
        newRegister = register;
    }

    public boolean hasNewRegister() {
        return newRegister;
    }

    public void setNewcoloredRegister(boolean coloredRegister) {
        newColoredRegister = coloredRegister;
    }

    public boolean hasNewColoredRegister() {
        return newColoredRegister;
    }

    public void setIsFull(boolean newIsFull) {
        isFull = newIsFull;
    }

    public boolean getIsFull() {
        return isFull;
    }

    public int howManyArtifacts() {
        int count = 0;
        for (ArtifactColor moulinStoragePositionColor : moulinStoragePositionColors) {
            if (moulinStoragePositionColor != ArtifactColor.NONE) {
                count++;
            }
        }
        return count;
    }

    private boolean isMoulinAtTarget() {
        return moulin.atTargetPosition();
    }

    /**
     * Power moulin if motor not at target position. Inside : recalibrate
     */
    private void powerMoulinIfNeeded() {
        if (!isMoulinAtTarget()) {
            moulin.setPower(POWER_MOULIN_ROTATION);

            setNewRegister(false);
            setNewcoloredRegister(false);

            if (wentRecalibrationOpposite() && isMagneticSwitch()) {
                recalibrateMoulin();
                setWentRecalibrationOpposite(false);
            }
        } else {
            moulin.setPower(0);
            if (getMoulinPosition() != MAGNETIC_ON_MOULIN_POSITION) {
                setWentRecalibrationOpposite(true);
            }
        }
    }

    /**
     * Idea here is to recalibrate the moulin position each time it is possible :
     * It's possible when the magnetic switch is touched
     */
    private void recalibrateMoulin() {
        // Here i want to make sure the remaining distance is a multiple of
        // INTERVALLE_TICKS_MOULIN
        int remainingDistance = Math.abs(getMoulinMotorRemainingDistance());

        // The remainingDistance should be close to a multiple of
        // INTERVALLE_TICKS_MOULIN
        // get the number of times INTERVALLE_TICKS_MOULIN fits in remainingDistance
        double intervals = (double) remainingDistance / INTERVALLE_TICKS_MOULIN;

        int intPartOfRounded = (int) Math.round(intervals);
        double differenceToIntRounded = (intervals - intPartOfRounded);
        double absDiff = Math.abs(differenceToIntRounded);

        int diffTicks = (int) Math.round(absDiff * INTERVALLE_TICKS_MOULIN);

        // recalibrate target
        if (diffTicks != 0) {
            // Determine direction: if target is higher than current, subtract remainder
            // If target is lower than current, add remainder
            if (differenceToIntRounded > 0) {
                incrementMoulinTargetPosition(-diffTicks + OFFSET_MAGNETIC_POS);
            } else {
                incrementMoulinTargetPosition(diffTicks + OFFSET_MAGNETIC_POS);
            }
        }

        // recalibrate moulin Pos
        if (intPartOfRounded > 0) {
            moulin.hardSetPosition(MAGNETIC_ON_MOULIN_POSITION + intPartOfRounded);
        } else if (intPartOfRounded < 0) {
            moulin.hardSetPosition(MAGNETIC_ON_MOULIN_POSITION - intPartOfRounded);
        }
    }

    public void hardSetMoulinPosition(int pos){
        moulin.hardSetPosition(pos);
    }

    public void setPIDF(double p, double i, double d, double f) {
        moulin.setPIDF(p, i, d, f);
    }

    public PIDFCoefficients getPIDF() {
        return moulin.getPIDF();
    }

    public com.qualcomm.robotcore.hardware.DcMotor.RunMode getMoulinRunMode() {
        return moulin.getRunMode();
    }

    public void setMoulinRunMode(com.qualcomm.robotcore.hardware.DcMotor.RunMode mode) {
        moulin.setRunMode(mode);
    }

    @Override
    public void periodic() {
        // required by Moulin
        powerMoulinIfNeeded();

        // if (!getIsFull()){
        //
        // }
        // Telemetry
        printMagneticTelemetry(telemetry);

        // printTrappeTelemetry(telemetry);
        // printColorTelemetry(telemetry);
        // printDistanceTelemetry(telemetry);
        printMoulinTelemetry(telemetry);
        printStoredArtifactsTelemetry(telemetry);
    }

    /**
     * telemetry Trappe
     */
    private void printTrappeTelemetry(final Telemetry telemetry) {
        telemetry.addData("trappe ouverte ?", trappe.isDoorOpen());
        // telemetry.addData("trappe angle", trappe.getAngle());
    }

    /**
     * Print magnetic telemetry
     */
    private void printMagneticTelemetry(final Telemetry telemetry) {
        telemetry.addData("magnticSwitch", magneticSwitch.isMagnetic());
    }

    /**
     * telemetry Moulin
     */
    private void printMoulinTelemetry(final Telemetry telemetry) {
        telemetry.addData("moulin ticks", getMoulinMotorPosition());
        telemetry.addData("moulinTarget", getMoulinMotorTargetPosition());
        telemetry.addData("moulin position", getMoulinPosition());
        telemetry.addData("remaining distance", getMoulinMotorRemainingDistance());
        PIDFCoefficients pidf = getPIDF();
        telemetry.addData("moulin pidf p", pidf.p);
        telemetry.addData("moulin pidf i", pidf.i);
        telemetry.addData("moulin pidf d", pidf.d);
        telemetry.addData("moulin pidf f", pidf.f);
        // telemetry.addData("wentOpposite", wentRecalibrationOpposite());
        // telemetry.addData("moulin at target", isMoulinAtTarget());
    }

    /**
     * telemetry Color Sensors
     */
    private void printColorTelemetry(final Telemetry telemetry) {
        // Color Sensor 1
        if (tripleColorSensors.isGreen(1)) {
            telemetry.addLine("CS1 Detects Green");
        } else if (tripleColorSensors.isPurple(1)) {
            telemetry.addLine("CS1 Detects Purple");
        }

        // Color Sensor 2
        if (tripleColorSensors.isGreen(2)) {
            telemetry.addLine("CS2 Detects Green");
        } else if (tripleColorSensors.isPurple(2)) {
            telemetry.addLine("CS2 Detects Purple");
        }
    }

    private void printDistanceTelemetry(final Telemetry telemetry) {
        telemetry.addData("Artefact in Trieur", isArtefactInTrieur());
        // Color Sensor 1
        telemetry.addData("CS1 Distance", tripleColorSensors.getDistance(1));
        // Color Sensor 2
        telemetry.addData("CS2 Distance", tripleColorSensors.getDistance(2));
    }

    /**
     * telemetry to show stored artifacts
     */
    private void printStoredArtifactsTelemetry(final Telemetry telemetry) {
        telemetry.addLine("=== Stored Artifacts ===");
        for (int i = 1; i <= 3; i++) {
            ArtifactColor color = getMoulinStoragePositionColor(i);
            if (color != ArtifactColor.NONE) {
                telemetry.addData("Storage position" + i, color.toString());
            }
        }

        telemetry.addData("Last registered color", getLastDetectedColor());
        telemetry.addData("isFull", getIsFull());
        telemetry.addData("Green shooting positions", getClosestShootingPositionForColor(ArtifactColor.GREEN));
        telemetry.addData("Purple shooting positions", getClosestShootingPositionForColor(ArtifactColor.PURPLE));
    }
}
