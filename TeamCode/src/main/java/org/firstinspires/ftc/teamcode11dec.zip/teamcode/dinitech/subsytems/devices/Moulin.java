package org.firstinspires.ftc.teamcode.dinitech.subsytems.devices;

import static com.qualcomm.robotcore.hardware.DcMotor.RunMode.RUN_TO_POSITION;
import static com.qualcomm.robotcore.hardware.DcMotor.RunMode.RUN_USING_ENCODER;
import static com.qualcomm.robotcore.hardware.DcMotor.RunMode.STOP_AND_RESET_ENCODER;
import static com.qualcomm.robotcore.hardware.DcMotor.ZeroPowerBehavior.BRAKE;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.INTERVALLE_TICKS_MOULIN;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.MOULIN_MOTOR_NAME;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.MOULIN_POSITION_TOLERANCE;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.PIDFCoefficients;

public class Moulin {
    /**
     * Moulin system :
     * 6 positions 60° apart. around an axis.
     * 3 of them are storage positions, 120° apart. There are storage positions 1, 2
     * and 3.
     * So i need a mapping form storage position to moulin position and back as
     * well.
     * 1 -> 1
     * 3 -> 2
     * 5 -> 3
     * moulinPosition is the position that is at the bottom of the moulin.
     * The bottom of the moulin is where artefacts can be charged in the moulin.
     * The top of the moulin is where artefacts can be shot from the moulin.
     * if moulinPosition = 1 : storage 1 is at the charging position
     * if moulinPosition = 2 : storage 3 is at the shooting position
     * if moulinPosition = 3 : storage 2 is at the charging position
     * if moulinPosition = 4 : storage 1 is at the shooting position
     * if moulinPosition = 5 : storage 3 is at the charging position
     * if moulinPosition = 6 : storage 2 is at the shooting position
     */
    public static final int MIN_POSITION = 1;
    public static final int MAX_POSITION = 6;
    public static final int TOTAL_POSITIONS = 6;

    private final DcMotorEx dcMotorEx;
    private static int moulinPosition;

    public Moulin(final HardwareMap hardwareMap) {
        dcMotorEx = hardwareMap.get(DcMotorEx.class, MOULIN_MOTOR_NAME);

        dcMotorEx.setZeroPowerBehavior(BRAKE);

        resetMoulin();

        setTargetPositionMotorTolerance(MOULIN_POSITION_TOLERANCE);
    }

    public void resetMoulin() {
        dcMotorEx.setMode(STOP_AND_RESET_ENCODER);
        setTargetPositionMotor(getMotorPosition());
        dcMotorEx.setMode(RUN_TO_POSITION);
        moulinPosition = 1;
    }

    /**
     * Helper method to get the next state in the sequence
     */
    private static int getNextPosition(int pos) {
        return pos == MAX_POSITION ? MIN_POSITION : pos + 1;
    }

    public static int getNNextPosition(int pos, int n) {
        int resultPos = pos;
        for (int i = 0; i < n; i++) {
            resultPos = getNextPosition(resultPos);
        }
        return resultPos;
    }

    /**
     * Helper method to get the previous state in the sequence
     */
    private static int getPreviousPosition(int pos) {
        return pos == MIN_POSITION ? MAX_POSITION : pos - 1;
    }

    public static int getNPreviousPosition(int pos, int n) {
        int resultPos = pos;
        for (int i = 0; i < n; i++) {
            resultPos = getPreviousPosition(resultPos);
        }
        return resultPos;
    }

    public void hardSetPosition(int pos) {
        moulinPosition = anyIntToMoulinPosition(pos);
    }

    public static int anyIntToMoulinPosition(int intPos) {
        int normalizedPos = ((intPos % TOTAL_POSITIONS) + TOTAL_POSITIONS) % TOTAL_POSITIONS; // ensure positive modulo
        if (normalizedPos == 0) {
            return TOTAL_POSITIONS;
        }
        return normalizedPos;
    }

    /**
     * Set the moulin to a specific state (1-6)
     * 
     * @param targetPos the target state (1-6)
     * @param makeShort if true, use shortest rotation path; if false, go through
     *                  all states in positive direction
     * @throws IllegalArgumentException if state is not between 1 and 6
     */
    public void setMoulinPosition(int targetPos, boolean makeShort) {
        if (!isValidPosition(targetPos)) {
            throw new IllegalArgumentException("Invalid moulin state: " + targetPos + ". Must be between "
                    + MIN_POSITION + " and " + MAX_POSITION);
        }

        int newTargetTicks;

        if (makeShort) {
            // Use shortest path logic - calculate relative to current position
            int optimalStateDifference = calculateOptimalStateDifference(moulinPosition, targetPos);

            // Calculate target position by moving the optimal number of steps from current
            // position
            newTargetTicks = (optimalStateDifference * INTERVALLE_TICKS_MOULIN);
        } else {
            // Go through all states in positive direction (clockwise)
            int stateDifference = calculatePositivePositionDifference(moulinPosition, targetPos);

            // Calculate target position by going the specified number of steps forward
            newTargetTicks = (stateDifference * INTERVALLE_TICKS_MOULIN);
        }

        incrementTargetPosition(newTargetTicks);
        moulinPosition = targetPos;
    }

    /**
     * Calculate the positive (clockwise) path between current and target state
     * Always goes in the positive direction through all states
     * 
     * @param currentPos the current Position
     * @param targetPos  the target Position
     * @return the number of positive steps to reach target (always positive)
     */
    public static int calculatePositivePositionDifference(int currentPos, int targetPos) {
        if (targetPos >= currentPos) {
            // Direct path in positive direction
            return targetPos - currentPos;
        } else {
            // Wrap around: go to max pos, then continue to target
            // Example: from position 2 to position 1 = (6-2+1) + (1-1) = 5 steps
            return (MAX_POSITION - currentPos) + (targetPos - MIN_POSITION + 1);
        }
    }

    /**
     * Calculate the optimal path (shortest rotation) between current and target
     * state
     * 
     * @param currentPos the current pos
     * @param targetPos  the target pos
     * @return the state difference using the shortest path (negative =
     *         counterclockwise, positive = clockwise)
     */
    public static int calculateOptimalStateDifference(int currentPos, int targetPos) {
        int directDifference = targetPos - currentPos;

        // Calculate alternative paths around the circle
        int positiveWrapDifference = directDifference - TOTAL_POSITIONS;
        int negativeWrapDifference = directDifference + TOTAL_POSITIONS;

        // Find the path with smallest absolute value (shortest rotation)
        int optimalDifference = directDifference;

        if (Math.abs(negativeWrapDifference) < Math.abs(optimalDifference)) {
            optimalDifference = negativeWrapDifference;
        }

        if (Math.abs(positiveWrapDifference) < Math.abs(optimalDifference)) {
            optimalDifference = positiveWrapDifference;
        }

        return optimalDifference;
    }

    /**
     * Find the closest position to the opposite current moulin position from an
     * array of possible positions
     * 
     * @param possiblePositions Array of positions to choose from
     * @return The closest state to the opposite current position, or -1 if array is
     *         empty
     */
    public static int getClosestPositionToShoot(int[] possiblePositions) {
        if (possiblePositions == null || possiblePositions.length == 0) {
            return -1;
        }

        int shootingPosition = getOppositePosition(moulinPosition);

        int closestPos = possiblePositions[0];
        int smallestDistance = Math.abs(calculateOptimalStateDifference(shootingPosition, possiblePositions[0]));

        for (int i = 1; i < possiblePositions.length; i++) {
            int distance = Math.abs(calculateOptimalStateDifference(shootingPosition, possiblePositions[i]));
            if (distance < smallestDistance) {
                smallestDistance = distance;
                closestPos = possiblePositions[i];
            }
        }

        return closestPos;
    }

    /**
     * Get the opposite position of a position (180 degrees rotation)
     * 
     * @param pos a position
     * @return the opposite position
     */
    public static int getOppositePosition(int pos) {
        return (pos + 3 - 1) % TOTAL_POSITIONS + 1; // +3 for opposite, -1 and +1 for 1-based indexing
    }

    private static boolean isValidPosition(int pos) {
        return pos >= MIN_POSITION && pos <= MAX_POSITION;
    }

    public void setTargetPositionMotor(int position) {
        dcMotorEx.setTargetPosition(position);
    }

    public void incrementTargetPosition(double incr) {
        int newTargetPosition = (int) incr + getTargetPosition();
        setTargetPositionMotor(newTargetPosition);
    }

    public int getTargetPosition() {
        return dcMotorEx.getTargetPosition();
    }

    public boolean atTargetPosition() {
        return !dcMotorEx.isBusy();
    }

    public void setPower(final double power) {
        dcMotorEx.setPower(power);
    }

    public double getPower() {
        return dcMotorEx.getPower();
    }

    public void setTargetPositionMotorTolerance(int error) {
        dcMotorEx.setTargetPositionTolerance(error); // allowed maximum error
    }

    public int getPosition() {
        return moulinPosition;
    }

    public static int getMoulinStoragePos(int pos) {
        if (pos == 1) {
            return 1;
        } else if (pos == 3) {
            return 2;
        } else if (pos == 5) {
            return 3;
        } else {
            throw new IllegalArgumentException("Cannot return the storage pos, pos is not a storage :" + pos);
        }
    }

    public static int getStoragePositionFromShootingPosition(int moulinPos) {
        if (moulinPos == 2) {
            return 3;
        } else if (moulinPos == 4) {
            return 1;
        } else if (moulinPos == 6) {
            return 2;
        } else {
            throw new IllegalArgumentException(
                    "Cannot return the storage pos, moulinPos is not a shooting pos for any pos :" + moulinPos);
        }
    }

    public int getMotorPosition() {
        return dcMotorEx.getCurrentPosition();
    }

    public int getRemainingDistance() {
        return getTargetPosition() - getMotorPosition();
    }

    public boolean isOverCurrent() {
        return dcMotorEx.isOverCurrent();
    }

    public boolean shouldStopPower() {
        return isOverCurrent() || atTargetPosition();
    }

    /**
     * Check if a state is a storage position (1, 3, 5)
     * 
     * @param pos the position to check
     * @return true if it's a storage position
     */
    public static boolean isStoragePosition(int pos) {
        return pos == 1 || pos == 3 || pos == 5;
    }

    /**
     * Check if a state is a shooting position (2, 4, 6)
     * 
     * @param pos the position to check
     * @return true if it's a shooting position
     */
    public static boolean isShootingPosition(int pos) {
        return pos == 2 || pos == 4 || pos == 6;
    }

    /**
     * Get the shooting position for a given storage position
     * 
     * @param storagePosition the storage position (1, 3, or 5)
     * @return the corresponding shooting position (4, 6, and 1)
     */
    public static int getShootingPositionFor(int storagePosition) {
        if (isShootingPosition(storagePosition)) {
            throw new IllegalArgumentException("Invalid storage pos: " + storagePosition);
        }
        return getOppositePosition(storagePosition);
    }

    /**
     * Get the storage position for a given shooting position
     * 
     * @param shootingPosition the shooting position (2, 4, or 6)
     * @return the corresponding storage position (1, 3, or 5)
     * @throws IllegalArgumentException if not a valid shooting state
     */
    public static int getStoragePositionFor(int shootingPosition) {
        if (isStoragePosition(shootingPosition)) {
            throw new IllegalArgumentException("Invalid shooting pos: " + shootingPosition);
        }
        return getOppositePosition(shootingPosition);
    }

    public void setPIDF(double p, double i, double d, double f) {
        // Motor is in RUN_TO_POSITION mode, so we need to set POSITION PID coefficients
        // NOT velocity coefficients
        dcMotorEx.setVelocityPIDFCoefficients(p, i, d, f);
        dcMotorEx.setPositionPIDFCoefficients(p);
    }

    public PIDFCoefficients getPIDF() {
        return dcMotorEx.getPIDFCoefficients(RUN_TO_POSITION);
    }

    /**
     * Get the current run mode of the motor
     * 
     * @return the current RunMode
     */
    public DcMotor.RunMode getRunMode() {
        return dcMotorEx.getMode();
    }

    /**
     * Set the run mode of the motor
     * 
     * @param mode the RunMode to set
     */
    public void setRunMode(DcMotor.RunMode mode) {
        dcMotorEx.setMode(mode);
    }

    /**
     * Get direct access to the motor (for advanced operations like auto-tuning)
     * 
     * @return the DcMotorEx instance
     */
    public DcMotorEx getMoulinMotor() {
        return dcMotorEx;
    }
}
