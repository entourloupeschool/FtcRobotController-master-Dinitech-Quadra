package org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.shooter;

import com.arcrobotics.ftclib.command.CommandBase;

import org.firstinspires.ftc.teamcode.dinitech.subsytems.ShooterSubsystem;

public class StopShooter extends CommandBase {
    private final ShooterSubsystem shooterSubsystem;

    public StopShooter(ShooterSubsystem shooterSubsystem) {
        this.shooterSubsystem = shooterSubsystem;
        addRequirements(shooterSubsystem);
    }

    @Override
    public void initialize(){
        shooterSubsystem.setVelocity(0);
    }


    @Override
    public boolean isFinished() {
        return shooterSubsystem.isSpeedEqual(0);
    }


}
