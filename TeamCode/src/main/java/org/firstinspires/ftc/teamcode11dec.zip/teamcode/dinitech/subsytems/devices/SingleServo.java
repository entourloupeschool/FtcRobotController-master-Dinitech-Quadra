package org.firstinspires.ftc.teamcode.dinitech.subsytems.devices;

import com.arcrobotics.ftclib.hardware.SimpleServo;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.arcrobotics.ftclib.hardware.ServoEx;

import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;

/**
 * Abstract base class for a single servo device with angle control.
 * Subclasses must provide a unique name for hardware mapping.
 */
public abstract class SingleServo {
    /** ServoEx instance for angle control */
    private final ServoEx servo;
    /** Minimum and maximum allowed servo angles (degrees) */
    private final double minAngle;
    private final double maxAngle;

    /**
     * Construct a SingleServo with default angle limits (-135, 135 degrees).
     * @param hardwareMap FTC hardware map
     */
    public SingleServo(final HardwareMap hardwareMap) {
        this(hardwareMap, -135, 135);
    }

    /**
     * Construct a SingleServo with custom angle limits.
     * @param hardwareMap FTC hardware map
     * @param minAngle Minimum allowed angle (degrees)
     * @param maxAngle Maximum allowed angle (degrees)
     */
    public SingleServo(final HardwareMap hardwareMap, final double minAngle, final double maxAngle) {
        this.minAngle = minAngle;
        this.maxAngle = maxAngle;
        this.servo = new SimpleServo(hardwareMap, getName(), minAngle, maxAngle, AngleUnit.DEGREES);
    }

    /**
     * @return Unique name for hardware mapping (must be implemented by subclass)
     */
    public abstract String getName();

    /**
     * @return Current servo angle (degrees)
     */
    public double getAngle() {
        return servo.getAngle(AngleUnit.DEGREES);
    }

    /**
     * Rotate the servo to a specific angle (degrees).
     * @param angle Target angle (degrees)
     */
    public void rotate(final double angle) {
        servo.turnToAngle(angle, AngleUnit.DEGREES);
    }

    /**
     * Incrementally rotate the servo by a given amount (degrees).
     * @param increment Angle increment (degrees)
     */
    public void incrementalRotation(final double increment) {
        double targetPosition = getAngle() + increment;
        servo.turnToAngle(targetPosition, AngleUnit.DEGREES);
    }

    /**
     * Move the servo to its default position (0 degrees).
     */
    public void defaultPosition() {
        servo.turnToAngle(0, AngleUnit.DEGREES);
    }

    /**
     * @return The underlying ServoEx instance (for advanced use)
     */
    public ServoEx getServo() {
        return servo;
    }

    /**
     * @return Minimum allowed angle (degrees)
     */
    public double getMinAngle() { return minAngle; }
    /**
     * @return Maximum allowed angle (degrees)
     */
    public double getMaxAngle() { return maxAngle; }
}
