package org.firstinspires.ftc.teamcode.dinitech.opmodes.tests;

import com.arcrobotics.ftclib.command.InstantCommand;
import com.arcrobotics.ftclib.command.RunCommand;
import com.arcrobotics.ftclib.command.button.Button;
import com.arcrobotics.ftclib.command.button.GamepadButton;
import com.arcrobotics.ftclib.gamepad.GamepadEx;
import com.arcrobotics.ftclib.gamepad.GamepadKeys;
import com.arcrobotics.ftclib.hardware.motors.MotorEx;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.Gamepad;

import org.firstinspires.ftc.teamcode.dinitech.opmodes.DinitechRobotBase;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.devices.Trappe;
//@TeleOp(name="MotorServoBasic - Dinitech", group="Test")
@Disabled
public class BasicMotorServo extends DinitechRobotBase {
    // Gamepads
    private GamepadEx m_driver;
    private final Gamepad currentGamepad1 = new Gamepad();
    private final Gamepad previousGamepad1 = new Gamepad();

    //public DcMotorEx simpleShooter;
    public MotorEx motorEx;
    public Trappe trappe;


    public RunCommand shooterRunCommand;
    private double powerToApply = 0;
    private Button cross1, square1, circle1, dpad_up, dpad_down, dpad_left;

    /**
     * Initialize the teleop OpMode, gamepads, buttons, and default commands.
     */
    @Override
    public void initialize() {
        super.initialize();

        motorEx = new MotorEx(hardwareMap, "simpleShooter");
        motorEx.setRunMode(MotorEx.RunMode.RawPower);
        motorEx.setZeroPowerBehavior(MotorEx.ZeroPowerBehavior.BRAKE);

        trappe = new Trappe(hardwareMap);

        setupGamePadsButtonBindings();
    }

    /**
     * Main OpMode loop. Updates gamepad states.
     */
    @Override
    public void run() {
        super.run();

        telemetry.addData("puissance moteur:", powerToApply * 100);
        telemetry.addData("ticks moteur:", motorEx.getCurrentPosition());
    }

    /**
     * Initialize GamepadEx wrappers for driver and operator.
     */
    private void setupGamePadsButtonBindings() {
        m_driver = new GamepadEx(gamepad1);

        // Define button actions here if needed
        square1 = new GamepadButton(m_driver, GamepadKeys.Button.X);
        cross1 = new GamepadButton(m_driver, GamepadKeys.Button.A);
        circle1 = new GamepadButton(m_driver, GamepadKeys.Button.B);
        dpad_up = new GamepadButton(m_driver, GamepadKeys.Button.DPAD_UP);
        dpad_down = new GamepadButton(m_driver, GamepadKeys.Button.DPAD_DOWN);
        dpad_left = new GamepadButton(m_driver, GamepadKeys.Button.DPAD_LEFT);

        /**
         * Bind analog position (double m_driver.getRightY()) to servo's incrementalRotation (double increment)
         */
        cross1.whileHeld(new RunCommand(() -> trappe.incrementalRotationUp()));
        square1.whileHeld(new RunCommand(() -> trappe.incrementalRotationDown()));
        circle1.whenPressed(new InstantCommand(() -> trappe.toggleTrappe()));

        dpad_up.whenPressed(new InstantCommand(() -> {
            powerToApply += 0.05;
            if (powerToApply > 1){
                powerToApply = 1;
            }
            motorEx.set(powerToApply);
        }));
        dpad_down.whenPressed(new InstantCommand(() -> {
            powerToApply -= 0.05;
            if (powerToApply < -1){
                powerToApply = -1;
            }
            motorEx.set(powerToApply);
        }));
        dpad_left.whenPressed(new InstantCommand(() -> {
            powerToApply = 0;
            motorEx.set(powerToApply);
        }));

    }
}
