package org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.trieur;

import com.arcrobotics.ftclib.command.CommandBase;

import org.firstinspires.ftc.teamcode.dinitech.subsytems.TrieurSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.devices.Moulin;

public class ClearMoulinShootingPos extends CommandBase {
    private final TrieurSubsystem trieurSubsystem;
    private final int pos;
    /**
     * Creates a ShootGreen Sequential Command Group
     * @param trieurSubsystem this command will run on
     */
    public ClearMoulinShootingPos(TrieurSubsystem trieurSubsystem, int shootingPos){
        this.trieurSubsystem = trieurSubsystem;
        this.pos = shootingPos;
    }

    @Override
    public void initialize(){
        if (!Moulin.isShootingPosition(pos)) {
            throw new IllegalArgumentException("Invalid shooting pos: " + pos);
        }

        trieurSubsystem.clearMoulinStoragePositionColor(Moulin.getStoragePositionFromShootingPosition(pos));
        trieurSubsystem.setIsFull(false);
    }

    @Override
    public boolean isFinished() {
        return true;
    }
}
