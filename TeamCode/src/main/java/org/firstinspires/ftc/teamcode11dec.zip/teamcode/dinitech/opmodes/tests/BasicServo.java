package org.firstinspires.ftc.teamcode.dinitech.opmodes.tests;

import com.arcrobotics.ftclib.command.InstantCommand;
import com.arcrobotics.ftclib.command.RunCommand;
import com.arcrobotics.ftclib.command.button.Button;
import com.arcrobotics.ftclib.command.button.GamepadButton;
import com.arcrobotics.ftclib.gamepad.GamepadEx;
import com.arcrobotics.ftclib.gamepad.GamepadKeys;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.Gamepad;
import com.qualcomm.robotcore.hardware.SwitchableLight;

import org.firstinspires.ftc.teamcode.dinitech.opmodes.DinitechRobotBase;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.TrieurSubsystem;

//@TeleOp(name="BasicServo - Dinitech", group="Test")
@Disabled
public class BasicServo extends DinitechRobotBase {
    // Gamepads
    private GamepadEx m_driver;

    // button
    private Button cross1, square1, circle1, triangle1;
    private TrieurSubsystem trieurSubsystem;
    /**
     * Initialize the teleop OpMode, gamepads, buttons, and default commands.
     */
    @Override
    public void initialize() {
        super.initialize();

        trieurSubsystem = new TrieurSubsystem(hardwareMap, telemetry);

        setupGamePadsButtonBindings();
    }

    /**
     * Main OpMode loop. Updates gamepad states.
     */
    @Override
    public void run() {
        super.run();
    }

    /**
     * Setup GamePads and Buttons and their associated commands.
     */
    private void setupGamePadsButtonBindings() {
        m_driver = new GamepadEx(gamepad1);

        // Define button actions here if needed
        square1 = new GamepadButton(m_driver, GamepadKeys.Button.X);
        cross1 = new GamepadButton(m_driver, GamepadKeys.Button.A);
        circle1 = new GamepadButton(m_driver, GamepadKeys.Button.B);
        triangle1 = new GamepadButton(m_driver, GamepadKeys.Button.Y);

        /**
         * Bind analog position (double m_driver.getRightY()) to servo's incrementalRotation (double increment)
         */
        cross1.whileHeld(new RunCommand(() -> trieurSubsystem.incrOpenTrappe()));
        square1.whileHeld(new RunCommand(() -> trieurSubsystem.incrCloseTrappe()));
        circle1.whenPressed(new InstantCommand(() -> trieurSubsystem.toggleTrappe()));

    }
}
