package org.firstinspires.ftc.teamcode.dinitech.commands.groups;

import com.arcrobotics.ftclib.command.ConditionalCommand;


import org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.gamepad.Rumble;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.GamepadSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.ShooterSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.TrieurSubsystem;

public class ShootAny extends ConditionalCommand {

    /**
     * Creates a ShootGreen Sequential Command Group
     */
    public ShootAny(TrieurSubsystem trieurSubsystem, ShooterSubsystem shooterSubsystem, GamepadSubsystem gamepadSubsystem){
        super(
                // Command to execute when condition is true (artifact of specified color found)
                new ShootMoulinState(trieurSubsystem, shooterSubsystem, trieurSubsystem.getClosestShootingPositionAnyColor()),
                // Command to execute when condition is false (no artifact of specified color)
                new Rumble(gamepadSubsystem, 3, 1),
                // Condition to evaluate
                () -> trieurSubsystem.getClosestShootingPositionAnyColor() > 0
        );

    }
}
