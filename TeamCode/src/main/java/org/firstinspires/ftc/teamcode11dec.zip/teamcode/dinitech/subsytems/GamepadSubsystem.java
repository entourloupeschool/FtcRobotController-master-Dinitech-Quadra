package org.firstinspires.ftc.teamcode.dinitech.subsytems;

import com.arcrobotics.ftclib.command.SubsystemBase;
import com.arcrobotics.ftclib.gamepad.GamepadEx;
import com.qualcomm.robotcore.hardware.Gamepad;

import org.firstinspires.ftc.robotcore.external.Telemetry;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.devices.GamepadWrapper;

public class GamepadSubsystem extends SubsystemBase {
    private final Telemetry telemetry;

    public final GamepadWrapper driver;
    public final GamepadWrapper operator;

    public GamepadSubsystem(Gamepad gamepad1, Gamepad gamepad2, Telemetry telemetry){
        this.driver = new GamepadWrapper(new GamepadEx(gamepad1), 1, 0.1, 0.1);
        this.operator = new GamepadWrapper(new GamepadEx(gamepad2), 0.1, 0.1, 1);
        this.telemetry = telemetry;
    }

    public GamepadEx getDriverEx(){
        return driver.getGamepadEx();
    }
    public GamepadEx getOperatorEx(){
        return operator.getGamepadEx();
    }
    public void driverRumble(int rumbleEffectNumber){
        driver.rumble(rumbleEffectNumber);
    }
    public void operatorRumble(int rumbleEffectNumber){
        operator.rumble(rumbleEffectNumber);
    }

    public void customRumble(Gamepad.RumbleEffect customRumbleEffect, int gamepadNumber){
        switch (gamepadNumber){
            case 1:
                driver.runCustomRumble(customRumbleEffect);
            case 2:
                operator.runCustomRumble(customRumbleEffect);
            case 3:
                driver.runCustomRumble(customRumbleEffect);
                operator.runCustomRumble(customRumbleEffect);
        }
    }

    @Override
    public void periodic() {
//        printGamepadTelemetry(telemetry);
    }

    /**
     * telemetry Trappe to draw on driverHub
     */
    private void printGamepadTelemetry(final Telemetry telemetry){
        telemetry.addData("ps value", getDriverEx().gamepad.ps);
        telemetry.addData("a value", getDriverEx().gamepad.a);
        telemetry.addData("b value", getDriverEx().gamepad.b);
        telemetry.addData("guide value", getDriverEx().gamepad.guide);
        telemetry.addData("share value", getDriverEx().gamepad.share);
        telemetry.addData("touchpad value", getDriverEx().gamepad.touchpad);
        telemetry.addData("touchpad_finger_1 value", getDriverEx().gamepad.touchpad_finger_1);
        telemetry.addData("touchpad_finger_1_x value", getDriverEx().gamepad.touchpad_finger_1_x);
        telemetry.addData("touchpad_finger_1_y value", getDriverEx().gamepad.touchpad_finger_1_y);

        telemetry.addData("touchpad_finger_2 value", getDriverEx().gamepad.touchpad_finger_2);
        telemetry.addData("touchpad_finger_2_x value", getDriverEx().gamepad.touchpad_finger_2_x);
        telemetry.addData("touchpad_finger_2_y value", getDriverEx().gamepad.touchpad_finger_2_y);
    }

}
