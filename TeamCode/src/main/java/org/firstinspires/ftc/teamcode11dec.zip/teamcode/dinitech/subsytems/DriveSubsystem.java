package org.firstinspires.ftc.teamcode.dinitech.subsytems;

import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.DRIVER_POWER_SCALER_TO_THE_POWER;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.SLOW_DRIVE_SCALE;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.TELE_DRIVE_POWER;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.TELE_DRIVE_POWER_TRIGGER_SCALE;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.pickCustomPowerFunc;

import com.acmerobotics.roadrunner.Action;
import com.acmerobotics.roadrunner.Pose2d;
import com.acmerobotics.roadrunner.PoseVelocity2d;
import com.acmerobotics.roadrunner.Vector2d;
import com.arcrobotics.ftclib.command.Subsystem;
import com.arcrobotics.ftclib.command.SubsystemBase;

import org.firstinspires.ftc.robotcore.external.Telemetry;
import org.firstinspires.ftc.teamcode.Localizer;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.devices.DinitechMecanumDrive;

import java.util.HashSet;
import java.util.Set;

/**
 * Subsystem for controlling the robot's drive base using a
 * MecanumDriveGordinator.
 * Provides teleop drive and telemetry reporting.
 */
public class DriveSubsystem extends SubsystemBase {
    /** Drive system abstraction */
    public DinitechMecanumDrive dinitechMecanumDrive;
    /** Telemetry for reporting drive status */
    private final Telemetry telemetry;

    private boolean isATLocked = false;
    private boolean isSlowDrive = false;

    private double lastTeleDriverPowerScale = TELE_DRIVE_POWER;

    /**
     * Construct the DriveSubsystem without vision integration.
     * 
     * @param dinitechMecanumDrive DinitechMecanumDrive instance
     * @param telemetry            Telemetry object
     */
    public DriveSubsystem(final DinitechMecanumDrive dinitechMecanumDrive, final Telemetry telemetry) {
        this.dinitechMecanumDrive = dinitechMecanumDrive;
        this.telemetry = telemetry;
        dinitechMecanumDrive.updatePoseEstimate();
    }

    /**
     * Teleop drive method using gamepad input and speed scaling.
     * 
     * @param translationX double Strafe input (-1 to 1)
     * @param translationY double Forward/backward input (-1 to 1)
     * @param rotation     double rotation input (-1 to 1)
     * @param powerScaler  double power scaler input (0 to 1)
     */
    public void teleDrive(final double translationX, final double translationY, final double rotation,
            final double powerScaler) {
        if (powerScaler != 0) {
            lastTeleDriverPowerScale = TELE_DRIVE_POWER_TRIGGER_SCALE * pickCustomPowerFunc(powerScaler, 1)
                    + TELE_DRIVE_POWER;
        }
        dinitechMecanumDrive.setDrivePowers(new PoseVelocity2d(
                new Vector2d(
                        translationY * lastTeleDriverPowerScale,
                        -translationX * lastTeleDriverPowerScale),
                -rotation * lastTeleDriverPowerScale));
    }

    public void teleSlowDrive(final double translationX, final double translationY, final double rotation,
            final double powerScaler) {

        dinitechMecanumDrive.setDrivePowers(new PoseVelocity2d(
                new Vector2d(
                        translationY * SLOW_DRIVE_SCALE,
                        -translationX * SLOW_DRIVE_SCALE),
                -rotation * SLOW_DRIVE_SCALE));
    }

    public void teleDriveUnscale(final double translationX, final double translationY, final double rotation,
            final double powerScaler) {
        dinitechMecanumDrive.setDrivePowers(new PoseVelocity2d(
                new Vector2d(
                        translationY,
                        -translationX),
                -rotation));
    }

    public void setIsATLocked(boolean newIsATLocked) {
        isATLocked = newIsATLocked;
    }

    public boolean getIsATLocked() {
        return isATLocked;
    }

    /**
     * Periodic telemetry reporting for drive system.
     */
    @Override
    public void periodic() {
        // printDriveTelemetry(telemetry);
    }

    /**
     * telemetry funciton to draw on driverHub
     */
    private void printDriveTelemetry(final Telemetry telemetry) {

    }

    public Set<Subsystem> getDriveSubsystemSet() {
        Set<Subsystem> setDriveSubsystem = new HashSet<Subsystem>();
        setDriveSubsystem.add(this);
        return setDriveSubsystem;
    }

    public Localizer getLocalizer() {
        return dinitechMecanumDrive.localizer;
    }

    public Pose2d getPose() {
        return getLocalizer().getPose();
    }

    public boolean isSlowDrive() {
        return isSlowDrive;
    }

    public void setIsSlowDrive(boolean slowDrive) {
        isSlowDrive = slowDrive;
    }

    /**
     * Build a short trajectory action for teleop precision mode with FIELD-CENTRIC
     * control.
     * Left stick controls movement relative to the FIELD (not robot orientation).
     * Right stick controls robot rotation.
     * 
     * @param velocityX desired X velocity in field frame (-1 to 1)
     * @param velocityY desired Y velocity in field frame (-1 to 1)
     * @param rotation  desired rotation (-1 to 1)
     * @param duration  trajectory duration in seconds
     * @return Action for following the trajectory
     */
    public Action buildTeleopTrajectoryAction(double velocityX, double velocityY,
            double rotation, double duration) {
        // Get current pose
        Pose2d currentPose = dinitechMecanumDrive.localizer.getPose();

        // Scale inputs to reasonable velocities (in inches per second for translation)
        double maxTranslationSpeed = 30.0; // inches per second
        double maxRotationSpeed = Math.PI; // radians per second

        // FIELD-CENTRIC: Calculate displacement directly in world frame
        // Left stick Y -> Forward on field (positive Y)
        // Left stick X -> Strafe right on field (positive X)
        double worldDeltaX = -velocityX * maxTranslationSpeed * duration; // Strafe (left stick X)
        double worldDeltaY = velocityY * maxTranslationSpeed * duration; // Forward (left stick Y)
        double deltaHeading = -rotation * maxRotationSpeed * duration; // Rotation (right stick X)

        // Calculate target position in world frame
        Vector2d targetPosition = new Vector2d(
                currentPose.position.x + worldDeltaX,
                currentPose.position.y + worldDeltaY);

        // Calculate target heading
        double targetHeading = currentPose.heading.toDouble() + deltaHeading;

        // Build trajectory action with higher constraint scale for responsive teleop
        return dinitechMecanumDrive.actionBuilder(currentPose, 1.5)
                .strafeTo(targetPosition)
                .turnTo(targetHeading)
                .build();
    }
}