package org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.vision;

import com.arcrobotics.ftclib.command.CommandBase;

import org.firstinspires.ftc.teamcode.dinitech.subsytems.VisionSubsystem;

public class UpdateAprilTagsDetections extends CommandBase {
    private VisionSubsystem visionSubsystem;

    public UpdateAprilTagsDetections(VisionSubsystem visionSubsystem){
        this.visionSubsystem = visionSubsystem;
        addRequirements(visionSubsystem);
    }
    @Override
    public void initialize(){
        /**
         * Update the april tags detection data
         */
        visionSubsystem.updateAprilTagDetections();
    }


    @Override
    public boolean isFinished() {
        return true;
    }
}
