package org.firstinspires.ftc.teamcode.dinitech.subsytems.devices;


import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.GAIN_DETECTION;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.GREEN_HUE_HIGHER;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.GREEN_HUE_LOWER;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.GREEN_RED_RGB_HIGHER;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.GREEN_SATURATION_LOWER;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.PURPLE_HUE_HIGHER;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.PURPLE_HUE_LOWER;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.SAMPLE_SIZE_TEST;

import com.qualcomm.robotcore.hardware.DistanceSensor;
import com.qualcomm.robotcore.hardware.NormalizedColorSensor;
import com.qualcomm.robotcore.hardware.NormalizedRGBA;

import android.graphics.Color;

import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;

import java.util.ArrayList;
import java.util.List;

/**
 * Classe wrapper pour un capteur de couleur avec moyennes glissantes
 */
public class AveragingColorSensor {
    public final NormalizedColorSensor sensor;

    // Listes pour les moyennes glissantes
    private final List<Double> redSamples = new ArrayList<>();
    private final List<Double> greenSamples = new ArrayList<>();
    private final List<Double> blueSamples = new ArrayList<>();
//    private List<Double> alphaSamples = new ArrayList<>();
    private final List<Double> hueSamples = new ArrayList<>();
    private final List<Double> saturationSamples = new ArrayList<>();
//    private final List<Double> brightnessSamples = new ArrayList<>();

    public AveragingColorSensor(NormalizedColorSensor sensor) {
        this.sensor = sensor;
        setGain(GAIN_DETECTION);
    }

    /**
     * Met à jour le capteur et ajoute les nouvelles valeurs aux moyennes
     */
    public void update() {
        NormalizedRGBA colors = sensor.getNormalizedColors();

        float[] hsvValues = new float[3];
        Color.colorToHSV(colors.toColor(), hsvValues);

        // Ajouter les nouvelles valeurs aux listes
        addSampleToList(redSamples, colors.red);
        addSampleToList(greenSamples, colors.green);
        addSampleToList(blueSamples, colors.blue);
//            addSampleToList(alphaSamples, colors.alpha);
        addSampleToList(hueSamples, hsvValues[0]);
        addSampleToList(saturationSamples, hsvValues[1]);
//            addSampleToList(brightnessSamples, hsvValues[2]);

    }

    // Méthodes d'accès aux moyennes
    public double getAverageRed() { return calculateAverage(redSamples); }
    public double getAverageGreen() { return calculateAverage(greenSamples); }
    public double getAverageBlue() { return calculateAverage(blueSamples); }
//    public double getAverageAlpha() { return calculateAverage(alphaSamples); }
    public double getAverageHue() { return calculateAverage(hueSamples); }
    public double getAverageSaturation() { return calculateAverage(saturationSamples); }
//    public double getAverageBrightness() { return calculateAverage(brightnessSamples); }
    public int getSampleCount() { return hueSamples.size(); }

    // Méthodes de détection de couleurs
    public boolean isGreen() {
        return isAverageHueBetween(GREEN_HUE_LOWER, GREEN_HUE_HIGHER) &&
                getAverageGreen() > getAverageBlue() && getAverageSaturation() > GREEN_SATURATION_LOWER && getAverageRed() < GREEN_RED_RGB_HIGHER;
    }

    public boolean isPurple() {
        return isAverageHueBetween(PURPLE_HUE_LOWER, PURPLE_HUE_HIGHER);
    }

    public double getDistance() {
        return ((DistanceSensor) sensor).getDistance(DistanceUnit.CM);
    }

    private boolean isAverageHueBetween(double lowerThreshold, double upperThreshold) {
        double averageHue = getAverageHue();
        return averageHue >= lowerThreshold && averageHue <= upperThreshold;
    }

    /**
     * Ajoute un échantillon à la liste et maintient la taille à SAMPLE_SIZE_TEST
     */
    private void addSampleToList(List<Double> list, double value) {
        list.add(value);
        if (list.size() > SAMPLE_SIZE_TEST) {
            list.remove(0);
        }
    }

    public void clearSamples() {
        redSamples.clear();
        greenSamples.clear();
        blueSamples.clear();
//        alphaSamples.clear();
        hueSamples.clear();
        saturationSamples.clear();
//        brightnessSamples.clear();
    }

    /**
     * Calcule la moyenne des valeurs dans la liste
     */
    private double calculateAverage(List<Double> list) {
        if (list.isEmpty()) return 0.0;

        double sum = 0.0;
        for (double value : list) {
            sum += value;
        }
        return sum / list.size();
    }

    public double getGain(){
        return sensor.getGain();
    }

    public void setGain(double gain){
        sensor.setGain((float) gain);
    }
}