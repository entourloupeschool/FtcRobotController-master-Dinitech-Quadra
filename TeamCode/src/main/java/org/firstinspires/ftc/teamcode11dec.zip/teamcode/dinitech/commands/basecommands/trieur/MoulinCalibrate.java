package org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.trieur;

import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.INTERVALLE_TICKS_MOULIN;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.MOULIN_ROTATE_SPEED_CALIBRATION;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.OFFSET_MAGNETIC_POS;

import com.arcrobotics.ftclib.command.CommandBase;

import org.firstinspires.ftc.teamcode.dinitech.subsytems.TrieurSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.devices.Moulin;

public class MoulinCalibrate extends CommandBase {
    private final TrieurSubsystem trieurSubsystem;

    /**
     * Creates a new MoulinRotateHoraire command.
     * 
     * @param trieurSubsystem the subsystem used by this command
     */
    public MoulinCalibrate(TrieurSubsystem trieurSubsystem) {
        this.trieurSubsystem = trieurSubsystem;
        addRequirements(trieurSubsystem);
    }

    @Override
    public void execute() {
        trieurSubsystem.incrementMoulinTargetPosition(MOULIN_ROTATE_SPEED_CALIBRATION);
    }

    @Override
    public boolean isFinished() {
        boolean overCurrent = trieurSubsystem.isMoulinOverCurrent();
        boolean magnetic = trieurSubsystem.isMagneticSwitch();
        return overCurrent || magnetic;
    }

    @Override
    public void end(boolean interrupted) {
        trieurSubsystem.resetTargetMoulinMotor();
        trieurSubsystem.incrementMoulinTargetPosition(OFFSET_MAGNETIC_POS);
    }
}
