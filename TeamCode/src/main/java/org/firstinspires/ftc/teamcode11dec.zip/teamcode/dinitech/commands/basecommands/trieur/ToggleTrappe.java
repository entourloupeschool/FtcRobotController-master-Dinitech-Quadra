package org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.trieur;

import com.arcrobotics.ftclib.command.CommandBase;

import org.firstinspires.ftc.teamcode.dinitech.subsytems.TrieurSubsystem;

public class ToggleTrappe extends CommandBase {
    private final TrieurSubsystem trieurSubsystem;

    /**
     * Creates a new ToggleDoor command.
     * @param trieurSubsystem the subsystem used by this command
     */
    public ToggleTrappe(TrieurSubsystem trieurSubsystem){
        this.trieurSubsystem = trieurSubsystem;
    }

    @Override
    public void initialize(){
        /**
         * Toggle the door state (open/close)
         */
        trieurSubsystem.toggleTrappe();
    }

    @Override
    public boolean isFinished() {
        return true;
    }
}
