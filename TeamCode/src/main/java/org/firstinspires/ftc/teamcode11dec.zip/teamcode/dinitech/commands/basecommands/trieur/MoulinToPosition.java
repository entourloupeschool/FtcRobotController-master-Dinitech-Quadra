package org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.trieur;

import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.POWER_MOULIN_ROTATION;

import com.arcrobotics.ftclib.command.CommandBase;

import org.firstinspires.ftc.teamcode.dinitech.subsytems.TrieurSubsystem;

public class MoulinToPosition extends CommandBase {
    private final TrieurSubsystem trieurSubsystem;
    protected int moulinTargetPosition;

    protected boolean makeShort;

    /**
     * Creates a new MoulinRotateHoraire command.
     * 
     * @param trieurSubsystem the subsystem used by this command
     */
    public MoulinToPosition(TrieurSubsystem trieurSubsystem, int moulinTargetPosition, boolean makeShort) {
        this.trieurSubsystem = trieurSubsystem;
        this.moulinTargetPosition = moulinTargetPosition;
        this.makeShort = makeShort;

        addRequirements(trieurSubsystem);
    }

    @Override
    public void initialize() {
        trieurSubsystem.rotateToMoulinPosition(moulinTargetPosition, makeShort);
    }

    @Override
    public boolean isFinished() {
        return trieurSubsystem.shouldMoulinStopPower();
    }

    @Override
    public void end(boolean interrupted) {
        if (interrupted){
            trieurSubsystem.resetTargetMoulinMotor();
        }

        // If command ended due to over-current (not interrupted), schedule correction
//        if (!interrupted && trieurSubsystem.isMoulinOverCurrent()) {
//            new MoulinCorrectOverCurrent(trieurSubsystem, this).schedule();
//        }
    }
}
