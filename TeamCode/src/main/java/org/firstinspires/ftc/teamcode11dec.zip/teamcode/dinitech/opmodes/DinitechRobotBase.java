package org.firstinspires.ftc.teamcode.dinitech.opmodes;

import com.acmerobotics.dashboard.FtcDashboard;
import com.acmerobotics.dashboard.config.Config;
import com.acmerobotics.dashboard.telemetry.MultipleTelemetry;
import com.acmerobotics.roadrunner.ftc.LynxFirmware;
import com.arcrobotics.ftclib.command.CommandOpMode;
import com.qualcomm.hardware.lynx.LynxModule;
import com.qualcomm.robotcore.hardware.VoltageSensor;
import com.qualcomm.robotcore.util.ElapsedTime;

import java.util.List;

@Config
public class DinitechRobotBase extends CommandOpMode {
    // System
    private List<LynxModule> hubs;
    private VoltageSensor voltageSensor;
    private final ElapsedTime timer = new ElapsedTime();

    /**
     * Initialize all hardware and subsystems.
     */
    @Override
    public void initialize(){
        timer.reset();

        telemetry = new MultipleTelemetry(telemetry, FtcDashboard.getInstance().getTelemetry());

        LynxFirmware.throwIfModulesAreOutdated(hardwareMap);

        hubs = hardwareMap.getAll(LynxModule.class);
        for (LynxModule hub : hubs) {
            hub.setBulkCachingMode(LynxModule.BulkCachingMode.AUTO);
        }
    }

    /**
     * Main OpMode loop. Handles voltage monitoring and cache clearing.
     */
    @Override
    public void run() {
        super.run();

        reportLoopTime();
//        clearBulkCache();

        telemetry.update();
    }



    /**
     * Report loop time to telemetry.
     */
    private void reportLoopTime() {
        telemetry.addData("hz ", 1 / (timer.seconds()));
        timer.reset();
    }

    /**
     * Clear the bulk cache for all hubs.
     */
    private void clearBulkCache() {
        for (LynxModule hub : hubs) {
            hub.clearBulkCache();
        }
    }
}
