package org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.drive;

import com.arcrobotics.ftclib.command.CommandBase;

import org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.gamepad.Rumble;
import org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.vision.ContinuousUpdateAprilTagsDetections;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.DriveSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.GamepadSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.VisionSubsystem;

/**
 * Default command that toggles between TeleDrive (normal) and TeleDriveLocked
 * (vision-assisted)
 * when the right bumper is pressed. This command manages the toggle state
 * persistently.
 */
public class ToggleVisionDrive extends CommandBase {
    private final DriveSubsystem driveSubsystem;
    private final VisionSubsystem visionSubsystem;
    private final GamepadSubsystem gamepadSubsystem;

    public ToggleVisionDrive(DriveSubsystem driveSubsystem, VisionSubsystem visionSubsystem,
            GamepadSubsystem gamepadSubsystem) {
        this.driveSubsystem = driveSubsystem;
        this.visionSubsystem = visionSubsystem;
        this.gamepadSubsystem = gamepadSubsystem;
    }

    @Override
    public void initialize() {
        driveSubsystem.getDefaultCommand().cancel();
        driveSubsystem.setIsSlowDrive(false);

        if (driveSubsystem.getIsATLocked()) {
            driveSubsystem.setDefaultCommand(new TeleDrive(driveSubsystem, gamepadSubsystem));
            driveSubsystem.setIsATLocked(false);
        } else {
            new Rumble(gamepadSubsystem, 3, 3).schedule();
            driveSubsystem.setDefaultCommand(new TeleDriveLocked(driveSubsystem, visionSubsystem, gamepadSubsystem));
            driveSubsystem.setIsATLocked(true);
        }

    }

    @Override
    public boolean isFinished() {
        // This command finishes immediately after scheduling the appropriate command
        return true;
    }

}