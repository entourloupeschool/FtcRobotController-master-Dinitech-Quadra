package org.firstinspires.ftc.teamcode.dinitech.opmodes.tele;

import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.BEGIN_POSE;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.SPEED_INCREMENT_SHOOTER;

import com.arcrobotics.ftclib.command.InstantCommand;
import com.arcrobotics.ftclib.command.ParallelCommandGroup;
import com.arcrobotics.ftclib.command.SequentialCommandGroup;
import com.arcrobotics.ftclib.command.button.Trigger;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.StopRobot;
import org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.chargeur.ToggleChargeur;
import org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.drive.ToggleSlowDrive;
import org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.drive.ToggleVisionDrive;
import org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.shooter.MaxSpeedShooter;
import org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.shooter.TeleShooter;
import org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.trieur.MoulinAntiRotate;
import org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.trieur.MoulinCalibrate;
import org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.trieur.MoulinCalibrationSequence;
import org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.trieur.MoulinNext;
import org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.trieur.MoulinNextNext;

import org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.drive.TeleDrive;
import org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.shooter.ToggleShooter;
import org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.trieur.MoulinRotate;
import org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.trieur.ReadyMotif;
import org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.trieur.ToggleTrappe;
import org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.vision.ContinuousUpdateAprilTagsDetections;
import org.firstinspires.ftc.teamcode.dinitech.commands.groups.ArtefactPickAway;
import org.firstinspires.ftc.teamcode.dinitech.commands.groups.AutomaticArtefactPickAway;
import org.firstinspires.ftc.teamcode.dinitech.commands.groups.ShootColor;
import org.firstinspires.ftc.teamcode.dinitech.commands.groups.ShootRevolution;
import org.firstinspires.ftc.teamcode.dinitech.commands.groups.ShootRevolutionVision;
import org.firstinspires.ftc.teamcode.dinitech.commands.groups.VisionShooter;
import org.firstinspires.ftc.teamcode.dinitech.opmodes.DinitechRobotBase;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.ChargeurSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.DriveSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.GamepadSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.ShooterSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.TrieurSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.VisionSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.devices.DinitechMecanumDrive;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.devices.GamepadWrapper;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.devices.Moulin;

@TeleOp(name = "GornetixTeleOp - Dinitech", group = "TeleOp")
public class GornetixTeleOp extends DinitechRobotBase {
    private GamepadSubsystem gamepadSubsystem;
        private TrieurSubsystem trieurSubsystem;
        private VisionSubsystem visionSubsystem;

        private ShooterSubsystem shooterSubsystem;
        private ChargeurSubsystem chargeurSubsystem;
        private DriveSubsystem driveSubsystem;

        /**
         * Initialize the teleop OpMode, gamepads, buttons, and default commands.
         */
        @Override
        public void initialize() {
                super.initialize();

                gamepadSubsystem = new GamepadSubsystem(gamepad1, gamepad2, telemetry);
                register(gamepadSubsystem);

                visionSubsystem = new VisionSubsystem(hardwareMap, telemetry);
                visionSubsystem.addAprilTagProcessor();
                visionSubsystem.buildVisionPortal();
                register(visionSubsystem);
                visionSubsystem.setDefaultCommand(new ContinuousUpdateAprilTagsDetections(visionSubsystem));

                driveSubsystem = new DriveSubsystem(new DinitechMecanumDrive(hardwareMap, visionSubsystem, BEGIN_POSE),
                                telemetry);
                register(driveSubsystem);
                driveSubsystem.setDefaultCommand(new TeleDrive(driveSubsystem, gamepadSubsystem));

                trieurSubsystem = new TrieurSubsystem(hardwareMap, telemetry);
                register(trieurSubsystem);

//                 trieurSubsystem.setMoulinStateColor();

                chargeurSubsystem = new ChargeurSubsystem(hardwareMap, telemetry);
                register(chargeurSubsystem);

                shooterSubsystem = new ShooterSubsystem(hardwareMap, telemetry);
                register(shooterSubsystem);

                setupGamePadsButtonBindings();

                new MoulinCalibrationSequence(trieurSubsystem).schedule();
        }

        /**
         * Main OpMode loop. Updates gamepad states.
         */
        @Override
        public void run() {
                super.run();
        }

        /**
         * Setup GamePads and Buttons and their associated commands.
         */
        private void setupGamePadsButtonBindings() {
            GamepadWrapper m_Driver = gamepadSubsystem.driver;
            GamepadWrapper m_Operator = gamepadSubsystem.operator;

            //Overwrite m1 & m2
            m_Driver.m1Button.whenPressed(new InstantCommand());
            m_Driver.m2Button.whenPressed(new InstantCommand());
            m_Operator.m1Button.whenPressed(new InstantCommand());
            m_Operator.m2Button.whenPressed(new InstantCommand());

            // Full stop robot
            m_Driver.touchpadButton.whenActive(new StopRobot(shooterSubsystem, chargeurSubsystem));
            m_Operator.touchpadButton.whenActive(new StopRobot(shooterSubsystem, chargeurSubsystem));

            // Driver controls
            m_Driver.circle.whenPressed(new ToggleShooter(shooterSubsystem));
            m_Driver.cross.whenPressed(new ToggleChargeur(chargeurSubsystem));
            m_Driver.triangle.whenPressed(new ToggleTrappe(trieurSubsystem));

            m_Driver.bump_left.whenPressed(new ToggleSlowDrive(driveSubsystem, gamepadSubsystem));
            m_Driver.bump_right
                            .whenPressed(new ToggleVisionDrive(driveSubsystem, visionSubsystem, gamepadSubsystem));



            // Operator controls
            m_Operator.dpad_up.toggleWhenPressed(new ShootRevolution(trieurSubsystem, shooterSubsystem));
            m_Operator.dpad_right.whenPressed(new MoulinNextNext(trieurSubsystem));
            m_Operator.dpad_left.whenPressed(new MoulinNext(trieurSubsystem));

            m_Operator.bump_right.whileHeld(new MoulinRotate(trieurSubsystem));
            m_Operator.bump_left.whileHeld(new MoulinAntiRotate(trieurSubsystem));

            m_Operator.cross.whenPressed(new ShootColor(trieurSubsystem, shooterSubsystem, gamepadSubsystem,
                            TrieurSubsystem.ArtifactColor.GREEN));
            m_Operator.square.whenPressed(new ShootColor(trieurSubsystem, shooterSubsystem, gamepadSubsystem,
                            TrieurSubsystem.ArtifactColor.PURPLE));
            m_Operator.triangle.whenPressed(new ArtefactPickAway(trieurSubsystem, gamepadSubsystem));
            m_Operator.circle.toggleWhenPressed(new AutomaticArtefactPickAway(trieurSubsystem,
                            chargeurSubsystem, gamepadSubsystem));

            shooterSubsystem.setDefaultCommand(new TeleShooter(shooterSubsystem, gamepadSubsystem));

//                 Automatic trigger: when trieur becomes full, spin up shooter to max speed and
//                 Moulin Motif Ready
            new Trigger(trieurSubsystem::getIsFull)
                    .whenActive(new ParallelCommandGroup(new ReadyMotif(trieurSubsystem, visionSubsystem,
                            gamepadSubsystem),
                            new VisionShooter(shooterSubsystem, visionSubsystem, false)
                    ));

                // Example trigger usage (you can uncomment and add commands as needed)
        }
}
