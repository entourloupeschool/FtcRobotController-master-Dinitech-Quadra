package org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.trieur;

import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.MOULIN_ROTATE_SPEED_CALIBRATION;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.OFFSET_MAGNETIC_POS;

import com.arcrobotics.ftclib.command.CommandBase;
import com.arcrobotics.ftclib.command.InstantCommand;
import com.arcrobotics.ftclib.command.SequentialCommandGroup;

import org.firstinspires.ftc.teamcode.dinitech.subsytems.TrieurSubsystem;

public class MoulinCalibrationSequence extends SequentialCommandGroup {
    /**
     * Creates a new MoulinRotateHoraire command.
     *
     * @param trieurSubsystem the subsystem used by this command
     */
    public MoulinCalibrationSequence(TrieurSubsystem trieurSubsystem) {
        addCommands(
                new MoulinCalibrate(trieurSubsystem),
                new MoulinNext(trieurSubsystem),
                new InstantCommand(() -> trieurSubsystem.hardSetMoulinPosition(1))
        );
        addRequirements(trieurSubsystem);
    }

}
