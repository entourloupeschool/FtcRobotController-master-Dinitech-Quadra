package org.firstinspires.ftc.teamcode.dinitech.commands.groups;

import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.SAMPLE_SIZE_TEST;

import com.arcrobotics.ftclib.command.ParallelRaceGroup;
import com.arcrobotics.ftclib.command.SequentialCommandGroup;
import com.arcrobotics.ftclib.command.WaitUntilCommand;

import org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.gamepad.ContinuousRumbleCustom;
import org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.trieur.UpdateColorSensorsDetections;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.GamepadSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.TrieurSubsystem;

public class DetectArtefact extends SequentialCommandGroup {
        public DetectArtefact(TrieurSubsystem trieurSubsystem, GamepadSubsystem gamepadSubsystem) {
                addCommands(
                        new ParallelRaceGroup(
                                new ContinuousRumbleCustom(gamepadSubsystem, 3, 0.2),
                                new WaitUntilCommand(trieurSubsystem::isArtefactInTrieur)
                        ),
                        new ParallelRaceGroup(
                                new UpdateColorSensorsDetections(trieurSubsystem, SAMPLE_SIZE_TEST),
                                new ContinuousRumbleCustom(gamepadSubsystem, 3, 0.4)));
        }
}
