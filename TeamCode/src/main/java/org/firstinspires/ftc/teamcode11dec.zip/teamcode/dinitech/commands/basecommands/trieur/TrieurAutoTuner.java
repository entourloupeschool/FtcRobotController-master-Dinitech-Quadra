package org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.trieur;

import com.arcrobotics.ftclib.command.CommandBase;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.PIDFCoefficients;

import org.firstinspires.ftc.robotcore.external.Telemetry;
import org.firstinspires.ftc.teamcode.dinitech.other.StepResponseAnalyzer;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.TrieurSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.TrieurSubsystemVelocity;

import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.INTERVALLE_TICKS_MOULIN;

/**
 * Command that automatically tunes PIDF coefficients for the trieur moulin
 * motor.
 * 
 * Uses unidirectional step response analysis to account for chain slack.
 * The moulin uses a chain drive that only works properly in the forward
 * (positive) direction.
 * Reverse motion introduces slack, so we only perform forward step tests.
 */
public class TrieurAutoTuner extends CommandBase {

    /**
     * Tuning phases
     */
    private enum TuningPhase {
        INITIALIZING, // Set up initial conditions
        STEP_RESPONSE_TEST, // Perform forward step response tests
        CALCULATING, // Calculate optimal PIDF
        VALIDATION, // Validate tuned values
        COMPLETE // Tuning finished
    }

    private final TrieurSubsystem trieurSubsystem;
    private final Telemetry telemetry;
    private final StepResponseAnalyzer analyzer;

    private TuningPhase currentPhase;
    private int currentStepTest;

    // Step response variables
    private int stepTestStartPosition;
    private int stepTestTargetPosition;
    private long stepTestStartTime;

    // Tuned PIDF values
    private double tunedP;
    private double tunedI;
    private double tunedD;
    private double tunedF;

    // Original PIDF values and run mode (for restoration if needed)
    private PIDFCoefficients originalPIDF;
    private DcMotor.RunMode originalRunMode;

    // Test parameters
    private static final int NUM_STEP_TESTS = 3; // Number of step tests to perform
    private static final long STEP_TEST_DURATION_MS = 2500; // Duration of each step test
    private static final long SETTLING_TIME_MS = 500; // Time to wait between tests
    private static final int VALIDATION_MOVEMENTS = 3;
    private int validationCount;
    private long settlingStartTime;
    private boolean isSettling;

    // Accumulated metrics from multiple tests
    private double totalOvershoot;
    private double totalRiseTime;
    private double totalSettlingTime;
    private int oscillationCount;

    private double pInit = 0.3;
    private double iInit = 0.0005;
    private double dInit = 0.05;
    private double fInit = 0.00000044;

    /**
     * Create a new auto-tuner command
     * 
     * @param trieurSubsystem The trieur subsystem to tune
     * @param telemetry       Telemetry for displaying progress
     */
    public TrieurAutoTuner(TrieurSubsystem trieurSubsystem, Telemetry telemetry) {
        this.trieurSubsystem = trieurSubsystem;
        this.telemetry = telemetry;
        this.analyzer = new StepResponseAnalyzer();
        addRequirements(trieurSubsystem);
    }

    @Override
    public void initialize() {
        currentPhase = TuningPhase.INITIALIZING;
        currentStepTest = 0;
        validationCount = 0;
        isSettling = false;

        // Reset accumulated metrics
        totalOvershoot = 0;
        totalRiseTime = 0;
        totalSettlingTime = 0;
        oscillationCount = 0;

        // Save original PIDF values and run mode
        originalPIDF = trieurSubsystem.getPIDF();

        // Start with robust PIDF values for testing to ensure movement
        // (P=5.0 provides ~1200 ticks/sec velocity for 60deg error)
        trieurSubsystem.setPIDF(pInit, iInit, dInit, fInit);

        telemetry.addLine("=== Auto-Tuning Started ===");
        telemetry.addLine("Using unidirectional step response method");
        telemetry.addLine("(Accounts for chain slack)");

        // Move to a known position (position 1)
        trieurSubsystem.rotateToMoulinPosition(1, true);
    }

    @Override
    public void execute() {
        switch (currentPhase) {
            case INITIALIZING:
                executeInitializing();
                break;
            case STEP_RESPONSE_TEST:
                executeStepResponseTest();
                break;
            case CALCULATING:
                executeCalculating();
                break;
            case VALIDATION:
                executeValidation();
                break;
            case COMPLETE:
                // Do nothing, waiting for command to finish
                break;
        }

        updateTelemetry();
    }

    /**
     * Phase 1: Initialize and prepare for testing
     */
    private void executeInitializing() {
        // Ensure motor has power for initial movement
        if (!trieurSubsystem.shouldMoulinStopPower()) {
            trieurSubsystem.setMoulinPower(1.0);
        }

        // Wait for moulin to reach initial position
        if (Math.abs(trieurSubsystem.getMoulinMotorRemainingDistance()) < 10) {
            // Start first step response test
            startNextStepTest();
            currentPhase = TuningPhase.STEP_RESPONSE_TEST;
        }
    }

    /**
     * Phase 2: Perform forward step response tests
     */
    private void executeStepResponseTest() {
        if (isSettling) {
            // Stop motor during settling period
            trieurSubsystem.setMoulinPower(0);

            // Wait for system to settle before next test
            if (System.currentTimeMillis() - settlingStartTime > SETTLING_TIME_MS) {
                isSettling = false;

                if (currentStepTest < NUM_STEP_TESTS) {
                    // Start next test
                    startNextStepTest();
                } else {
                    // All tests complete, move to calculation
                    currentPhase = TuningPhase.CALCULATING;
                }
            }
            return;
        }

        long currentTime = System.currentTimeMillis();
        int currentPosition = trieurSubsystem.getMoulinMotorPosition();

        // Record data point
        analyzer.recordSample(currentPosition, currentTime);

        // Check if test duration elapsed
        if (currentTime - stepTestStartTime > STEP_TEST_DURATION_MS) {
            analyzer.stopRecording();

            // Analyze this test
            StepResponseAnalyzer.Metrics metrics = analyzer.analyze();
            if (metrics != null) {
                totalOvershoot += metrics.overshootPercent;
                totalRiseTime += metrics.riseTime;
                totalSettlingTime += metrics.settlingTime;
                if (metrics.hasOscillation) {
                    oscillationCount++;
                }
            }

            // Start settling period
            isSettling = true;
            settlingStartTime = currentTime;
        }
    }

    /**
     * Start the next step response test
     */
    private void startNextStepTest() {
        currentStepTest++;

        stepTestStartPosition = trieurSubsystem.getMoulinMotorPosition();
        stepTestTargetPosition = stepTestStartPosition + INTERVALLE_TICKS_MOULIN;

        // Set target position
        trieurSubsystem.setMoulinTargetPosition(stepTestTargetPosition);

        analyzer.startRecording(stepTestStartPosition, stepTestTargetPosition);
        stepTestStartTime = System.currentTimeMillis();
    }

    /**
     * Phase 3: Calculate optimal PIDF based on collected data
     */
    private void executeCalculating() {
        // Calculate average metrics
        double avgOvershoot = totalOvershoot / NUM_STEP_TESTS;
        double avgRiseTime = totalRiseTime / NUM_STEP_TESTS;
        double avgSettlingTime = totalSettlingTime / NUM_STEP_TESTS;
        boolean hasOscillation = oscillationCount > (NUM_STEP_TESTS / 2);

        // Calculate PIDF using empirical rules for chain-driven systems
        calculatePIDFFromMetrics(avgOvershoot, avgRiseTime, avgSettlingTime, hasOscillation);

        // Apply tuned PIDF
        trieurSubsystem.setPIDF(tunedP, tunedI, tunedD, tunedF);

        // Move to validation phase
        currentPhase = TuningPhase.VALIDATION;
        validationCount = 0;

        // Start first validation movement (forward only)
        trieurSubsystem.rotateToMoulinPosition(3, false); // false = don't use shortest path
    }

    /**
     * Calculate PIDF values from step response metrics
     * Uses empirical tuning rules optimized for chain-driven systems with slack
     */
    private void calculatePIDFFromMetrics(double overshoot, double riseTime, double settlingTime,
            boolean hasOscillation) {
        // Start with a more aggressive P value for chain systems
        // Chain slack reduces effective stiffness, so we need higher P
        tunedP = Math.max(pInit, 5.0); // Start at least at 5.0

        // === TUNE P BASED ON RISE TIME ===
        // Rise time indicates how responsive the system is
        if (riseTime > 1000) {
            // Very slow response - significantly increase P
            tunedP *= 2.0;
        } else if (riseTime > 700) {
            // Slow response - increase P moderately
            tunedP *= 1.5;
        } else if (riseTime < 200) {
            // Very fast - may be too aggressive
            tunedP *= 0.7;
        } else if (riseTime < 350) {
            // A bit fast - slightly reduce
            tunedP *= 0.85;
        }
        // Ideal rise time is 350-700ms, no adjustment needed in that range

        // === ADJUST P BASED ON OVERSHOOT ===
        // Overshoot indicates stability vs aggressiveness trade-off
        if (overshoot > 25) {
            // Severe overshoot - reduce P significantly
            tunedP *= 0.6;
        } else if (overshoot > 15) {
            // Moderate overshoot - reduce P
            tunedP *= 0.75;
        } else if (overshoot < 2 && riseTime < 600) {
            // Very little overshoot and decent speed - can be more aggressive
            tunedP *= 1.15;
        }
        // Ideal overshoot is 5-15%, no adjustment needed

        // === CALCULATE D (DERIVATIVE) ===
        // D helps dampen oscillations and reduce overshoot
        // For chain systems, D is crucial to prevent bouncing from slack
        if (hasOscillation) {
            // System is oscillating - need strong damping
            tunedD = tunedP * 0.25; // 25% of P
        } else if (overshoot > 20) {
            // High overshoot but not oscillating yet - add damping
            tunedD = tunedP * 0.20; // 20% of P
        } else if (overshoot > 10) {
            // Moderate overshoot - moderate damping
            tunedD = tunedP * 0.12; // 12% of P
        } else if (overshoot > 5) {
            // Small overshoot - light damping
            tunedD = tunedP * 0.08; // 8% of P
        } else {
            // Minimal overshoot - minimal damping
            tunedD = tunedP * 0.05; // 5% of P
        }

        // === CALCULATE I (INTEGRAL) ===
        // For chain systems, use VERY minimal I to avoid wind-up from slack
        // I helps eliminate steady-state error but can cause issues with mechanical
        // slack
        if (settlingTime > 2000) {
            // Very slow settling - moderate I to help reach target
            tunedI = tunedP * 0.08;
        } else if (settlingTime > 1500) {
            // Slow settling - small I
            tunedI = tunedP * 0.04;
        } else if (settlingTime > 1000) {
            // Acceptable settling - minimal I
            tunedI = tunedP * 0.02;
        } else {
            // Good settling - very minimal I (just to handle any steady-state error)
            tunedI = tunedP * 0.01;
        }

        // For chain systems with slack, reduce I further to prevent wind-up
        tunedI *= 0.5;

        // === F (FEEDFORWARD) ===
        // For position control with RUN_TO_POSITION, F is typically not needed
        // The controller handles feedforward internally
        tunedF = 0.0;

        // === SAFETY LIMITS ===
        // Ensure values are within safe operational ranges
        tunedP = Math.max(1.0, Math.min(tunedP, 20.0)); // P: 1.0 - 20.0
        tunedI = Math.max(0.0, Math.min(tunedI, 3.0)); // I: 0.0 - 3.0
        tunedD = Math.max(0.0, Math.min(tunedD, 5.0)); // D: 0.0 - 5.0
        tunedF = Math.max(0.0, Math.min(tunedF, 1.0)); // F: 0.0 - 1.0
    }

    /**
     * Phase 4: Validate tuned values with test movements (forward only)
     */
    private void executeValidation() {
        // Check if current movement is complete
        if (Math.abs(trieurSubsystem.getMoulinMotorRemainingDistance()) < 10) {
            validationCount++;

            if (validationCount < VALIDATION_MOVEMENTS) {
                // Perform next validation movement (always forward)
                int currentPos = trieurSubsystem.getMoulinPosition();
                int nextPosition = (currentPos % 6) + 1; // Always move forward
                trieurSubsystem.rotateToMoulinPosition(nextPosition, false);
            } else {
                // Validation complete
                currentPhase = TuningPhase.COMPLETE;
            }
        }
    }

    /**
     * Update telemetry with current tuning status
     */
    private void updateTelemetry() {
        telemetry.addLine("=== Auto-Tuning Progress ===");
        telemetry.addData("Phase", currentPhase.toString());

        // Always show motor status for debugging
        telemetry.addLine("--- Motor Status ---");
        telemetry.addData("Position", trieurSubsystem.getMoulinMotorPosition());
        telemetry.addData("Target", trieurSubsystem.getMoulinMotorTargetPosition());
        telemetry.addData("Remaining", trieurSubsystem.getMoulinMotorRemainingDistance());
        telemetry.addData("Moulin Pos", trieurSubsystem.getMoulinPosition());

        switch (currentPhase) {
            case INITIALIZING:
                telemetry.addLine("Moving to initial position...");
                break;
            case STEP_RESPONSE_TEST:
                if (isSettling) {
                    telemetry.addLine("Settling (motor stopped)...");
                    long settleRemaining = SETTLING_TIME_MS - (System.currentTimeMillis() - settlingStartTime);
                    telemetry.addData("Settle Time", String.format("%.1fs", settleRemaining / 1000.0));
                } else {
                    telemetry.addData("Step Test", currentStepTest + "/" + NUM_STEP_TESTS);
                    telemetry.addData("Samples", analyzer.getSampleCount());
                    long elapsed = System.currentTimeMillis() - stepTestStartTime;
                    telemetry.addData("Progress", String.format("%.1f%%", 100.0 * elapsed / STEP_TEST_DURATION_MS));
                    telemetry.addData("Test Start Pos", stepTestStartPosition);
                    telemetry.addData("Test Target", stepTestTargetPosition);
                }
                break;
            case CALCULATING:
                telemetry.addLine("Analyzing data...");
                if (NUM_STEP_TESTS > 0) {
                    telemetry.addData("Avg Overshoot", String.format("%.1f%%", totalOvershoot / NUM_STEP_TESTS));
                    telemetry.addData("Avg Rise Time", String.format("%.0f ms", totalRiseTime / NUM_STEP_TESTS));
                }
                break;
            case VALIDATION:
                telemetry.addData("Validation", validationCount + "/" + VALIDATION_MOVEMENTS);
                break;
            case COMPLETE:
                telemetry.addLine("=== Tuning Complete ===");
                telemetry.addData("P", String.format("%.6f", tunedP));
                telemetry.addData("I", String.format("%.6f", tunedI));
                telemetry.addData("D", String.format("%.6f", tunedD));
                telemetry.addData("F", String.format("%.6f", tunedF));
                telemetry.addLine("");
                telemetry.addLine("Note: Tuned for forward motion only");
                telemetry.addLine("(Chain slack in reverse)");
                break;
        }
    }

    @Override
    public boolean isFinished() {
        return currentPhase == TuningPhase.COMPLETE;
    }

    @Override
    public void end(boolean interrupted) {
        if (interrupted) {
            // Restore original PIDF if interrupted
            trieurSubsystem.setPIDF(originalPIDF.p, originalPIDF.i, originalPIDF.d, originalPIDF.f);
            telemetry.addLine("Auto-tuning interrupted - restored original PIDF");
        } else {
            telemetry.addLine("Auto-tuning complete!");
            telemetry.addLine("New PIDF values applied.");
            telemetry.addLine("Optimized for forward motion (chain-driven system)");
        }
    }

    /**
     * Get the tuned PIDF coefficients
     */
    public PIDFCoefficients getTunedPIDF() {
        return new PIDFCoefficients(tunedP, tunedI, tunedD, tunedF);
    }

    /**
     * Get the original PIDF coefficients
     */
    public PIDFCoefficients getOriginalPIDF() {
        return originalPIDF;
    }
}
