package org.firstinspires.ftc.teamcode.dinitech.subsytems;

import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.CHARGEUR_MOTOR_NAME;

import com.arcrobotics.ftclib.command.SubsystemBase;
import com.arcrobotics.ftclib.hardware.motors.Motor;
import com.arcrobotics.ftclib.hardware.motors.MotorEx;
import com.qualcomm.robotcore.hardware.HardwareMap;

import org.firstinspires.ftc.robotcore.external.Telemetry;

public class ChargeurSubsystem extends SubsystemBase {
    private final MotorEx motorEx;
    public final Telemetry telemetry;

    public ChargeurSubsystem(HardwareMap hardwareMap, Telemetry telemetry){
        this.motorEx = new MotorEx(hardwareMap, CHARGEUR_MOTOR_NAME);
        motorEx.setZeroPowerBehavior(Motor.ZeroPowerBehavior.FLOAT);
        motorEx.setRunMode(Motor.RunMode.RawPower);

        this.telemetry = telemetry;
    }

    public void setPower(double power){
        motorEx.set(power);
    }

    public double getPower(){
        return motorEx.get();
    }

    public void incrementPower(double powerIncrement){
        setPower(getPower() + powerIncrement);
    }

    public double getSpeed(){
        return motorEx.getVelocity();
    }

    public boolean isPowered(){
        return Math.abs(getPower()) > 0.1;
    }

    public boolean shouldStopPower(){
        return isOverCurrent();
    }


    public boolean isAtSpeed(double speed){
        return getSpeed() >= speed;
    }

    public boolean isOverCurrent(){
        return motorEx.motorEx.isOverCurrent();
    }

    @Override
    public void periodic(){
        // Required for chargeur
        if (isOverCurrent()){
            setPower(0);
        }

//        printChargeurTelemetry(telemetry);
    }

    private void printChargeurTelemetry(final Telemetry telemetry){
        telemetry.addData("chargeur power", getPower());
    }
}
