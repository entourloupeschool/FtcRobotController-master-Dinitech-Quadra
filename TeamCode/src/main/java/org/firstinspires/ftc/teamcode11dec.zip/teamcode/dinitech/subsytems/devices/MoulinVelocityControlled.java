package org.firstinspires.ftc.teamcode.dinitech.subsytems.devices;

import static com.qualcomm.robotcore.hardware.DcMotor.RunMode.RUN_USING_ENCODER;
import static com.qualcomm.robotcore.hardware.DcMotor.RunMode.STOP_AND_RESET_ENCODER;
import static com.qualcomm.robotcore.hardware.DcMotor.ZeroPowerBehavior.BRAKE;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.INTERVALLE_TICKS_MOULIN;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.MOULIN_MOTOR_NAME;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.MOULIN_POSITION_TOLERANCE;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.PIDFCoefficients;
import com.qualcomm.robotcore.util.Range;

/**
 * Velocity-controlled Moulin implementation with TUNABLE PIDF coefficients.
 * 
 * This version uses RUN_USING_ENCODER mode instead of RUN_TO_POSITION,
 * allowing custom PIDF coefficients to be set and tuned.
 * 
 * Position control is implemented manually using velocity control.
 * This enables the auto-tuner to work with chain-driven systems.
 */
public class MoulinVelocityControlled {
    /**
     * Moulin system constants (same as original Moulin)
     */
    public static final int MIN_POSITION = 1;
    public static final int MAX_POSITION = 6;
    public static final int TOTAL_POSITIONS = 6;

    private DcMotorEx dcMotorEx;
    private static int moulinPosition;

    // Position control variables
    private int targetPosition;
    private int positionTolerance;

    // Position PID coefficients (Outer Loop)
    private double posP = 5.0; // Default sturdy P gain
    private double posI = 0.0;
    private double posD = 0.0;
    private double posF = 0.0;

    // State variables for PID
    private int lastError = 0;
    private double accumulatedError = 0;
    private long lastUpdateTime = 0;

    // Maximum velocity (ticks per second)
    private static final int MAX_VELOCITY = 2000;

    public MoulinVelocityControlled(final HardwareMap hardwareMap) {
        dcMotorEx = hardwareMap.get(DcMotorEx.class, MOULIN_MOTOR_NAME);
        dcMotorEx.setZeroPowerBehavior(BRAKE);

        // Initialize motor with robust VELOCITY PIDF coefficients
        // These control the inner loop and ensure the motor achieves requested
        // velocities
        PIDFCoefficients velPIDF = dcMotorEx.getPIDFCoefficients(DcMotor.RunMode.RUN_USING_ENCODER);
        // Ensure we have some reasonable defaults if they seem wrong or zero
        if (velPIDF.p == 0)
            velPIDF.p = 10.0;
        if (velPIDF.i == 0)
            velPIDF.i = 3.0;
        dcMotorEx.setPIDFCoefficients(DcMotor.RunMode.RUN_USING_ENCODER, velPIDF);

        resetMoulin();

        setTargetPositionMotorTolerance(MOULIN_POSITION_TOLERANCE);
    }

    public void resetMoulin() {
        dcMotorEx.setMode(STOP_AND_RESET_ENCODER);
        dcMotorEx.setMode(RUN_USING_ENCODER);
        targetPosition = getMotorPosition();
        moulinPosition = 1;
        lastError = 0;
        lastUpdateTime = System.currentTimeMillis();
    }

    // ========== POSITION CONTROL METHODS (same interface as original) ==========

    /**
     * Helper method to get the next state in the sequence
     */
    private static int getNextPosition(int pos) {
        return pos == MAX_POSITION ? MIN_POSITION : pos + 1;
    }

    public static int getNNextPosition(int pos, int n) {
        int resultPos = pos;
        for (int i = 0; i < n; i++) {
            resultPos = getNextPosition(resultPos);
        }
        return resultPos;
    }

    /**
     * Helper method to get the previous state in the sequence
     */
    private static int getPreviousPosition(int pos) {
        return pos == MIN_POSITION ? MAX_POSITION : pos - 1;
    }

    public static int getNPreviousPosition(int pos, int n) {
        int resultPos = pos;
        for (int i = 0; i < n; i++) {
            resultPos = getPreviousPosition(resultPos);
        }
        return resultPos;
    }

    public void hardSetMoulinPosition(int pos) {
        moulinPosition = anyIntToMoulinPosition(pos);
    }

    public static int anyIntToMoulinPosition(int intPos) {
        int normalizedPos = ((intPos % TOTAL_POSITIONS) + TOTAL_POSITIONS) % TOTAL_POSITIONS;
        if (normalizedPos == 0) {
            return TOTAL_POSITIONS;
        }
        return normalizedPos;
    }

    /**
     * Set the moulin to a specific state (1-6)
     */
    public void setMoulinPosition(int targetPos, boolean makeShort) {
        if (!isValidPosition(targetPos)) {
            throw new IllegalArgumentException("Invalid moulin state: " + targetPos + ". Must be between "
                    + MIN_POSITION + " and " + MAX_POSITION);
        }

        int newTargetTicks;

        if (makeShort) {
            int optimalStateDifference = calculateOptimalStateDifference(moulinPosition, targetPos);
            newTargetTicks = (optimalStateDifference * INTERVALLE_TICKS_MOULIN);
        } else {
            int stateDifference = calculatePositivePositionDifference(moulinPosition, targetPos);
            newTargetTicks = (stateDifference * INTERVALLE_TICKS_MOULIN);
        }

        incrementTargetPosition(newTargetTicks);
        moulinPosition = targetPos;
    }

    public static int calculatePositivePositionDifference(int currentPos, int targetPos) {
        if (targetPos >= currentPos) {
            return targetPos - currentPos;
        } else {
            return (MAX_POSITION - currentPos) + (targetPos - MIN_POSITION + 1);
        }
    }

    public static int calculateOptimalStateDifference(int currentPos, int targetPos) {
        int directDifference = targetPos - currentPos;
        int positiveWrapDifference = directDifference - TOTAL_POSITIONS;
        int negativeWrapDifference = directDifference + TOTAL_POSITIONS;

        int optimalDifference = directDifference;

        if (Math.abs(negativeWrapDifference) < Math.abs(optimalDifference)) {
            optimalDifference = negativeWrapDifference;
        }

        if (Math.abs(positiveWrapDifference) < Math.abs(optimalDifference)) {
            optimalDifference = positiveWrapDifference;
        }

        return optimalDifference;
    }

    public static int getClosestPositionToShoot(int[] possiblePositions) {
        if (possiblePositions == null || possiblePositions.length == 0) {
            return -1;
        }

        int shootingPosition = getOppositePosition(moulinPosition);
        int closestPos = possiblePositions[0];
        int smallestDistance = Math.abs(calculateOptimalStateDifference(shootingPosition, possiblePositions[0]));

        for (int i = 1; i < possiblePositions.length; i++) {
            int distance = Math.abs(calculateOptimalStateDifference(shootingPosition, possiblePositions[i]));
            if (distance < smallestDistance) {
                smallestDistance = distance;
                closestPos = possiblePositions[i];
            }
        }

        return closestPos;
    }

    public static int getOppositePosition(int pos) {
        return (pos + 3 - 1) % TOTAL_POSITIONS + 1;
    }

    private static boolean isValidPosition(int pos) {
        return pos >= MIN_POSITION && pos <= MAX_POSITION;
    }

    public void setTargetPositionMotor(int position) {
        targetPosition = position;
    }

    public void incrementTargetPosition(double incr) {
        int newTargetPosition = (int) incr + getTargetPosition();
        setTargetPositionMotor(newTargetPosition);
    }

    public int getTargetPosition() {
        return targetPosition;
    }

    /**
     * Check if motor has reached target position (within tolerance)
     */
    public boolean atTargetPosition() {
        return Math.abs(getRemainingDistance()) <= positionTolerance;
    }

    /**
     * CRITICAL: Call this method periodically (every loop iteration)
     * to update motor velocity based on position error.
     * 
     * This replaces the automatic behavior of RUN_TO_POSITION mode.
     */
    public void updatePositionControl() {
        int currentPosition = getMotorPosition();
        int error = targetPosition - currentPosition;
        long currentTime = System.currentTimeMillis();
        double dt = (currentTime - lastUpdateTime) / 1000.0; // seconds

        if (dt == 0)
            return; // Prevention

        // P Term
        double pTerm = posP * error;

        // I Term (with anti-windup if needed, simple for now)
        accumulatedError += error * dt;
        double iTerm = posI * accumulatedError;

        // D Term
        double derivative = (error - lastError) / dt;
        double dTerm = posD * derivative;

        // F Term (Feedforward)
        double fTerm = posF * Math.signum(error); // Static friction compensation

        // Calculate desired velocity
        double velocity = pTerm + iTerm + dTerm + fTerm;

        // Clamp velocity to maximum
        velocity = Range.clip(velocity, -MAX_VELOCITY, MAX_VELOCITY);

        // Set motor velocity
        dcMotorEx.setVelocity(velocity);

        // Update state
        lastError = error;
        lastUpdateTime = currentTime;
    }

    /**
     * Set motor power directly (bypasses position control)
     * Use for manual control or when position control is not needed
     */
    public void setPower(final double power) {
        dcMotorEx.setPower(power);
    }

    public double getPower() {
        return dcMotorEx.getPower();
    }

    public void setTargetPositionMotorTolerance(int error) {
        positionTolerance = error;
    }

    public int getPosition() {
        return moulinPosition;
    }

    public static int getMoulinStoragePos(int pos) {
        if (pos == 1) {
            return 1;
        } else if (pos == 3) {
            return 2;
        } else if (pos == 5) {
            return 3;
        } else {
            throw new IllegalArgumentException("Cannot return the storage pos, pos is not a storage :" + pos);
        }
    }

    public static int getStoragePositionFromShootingPosition(int moulinPos) {
        if (moulinPos == 2) {
            return 3;
        } else if (moulinPos == 4) {
            return 1;
        } else if (moulinPos == 6) {
            return 2;
        } else {
            throw new IllegalArgumentException(
                    "Cannot return the storage pos, moulinPos is not a shooting pos for any pos :" + moulinPos);
        }
    }

    public int getMotorPosition() {
        return dcMotorEx.getCurrentPosition();
    }

    public int getRemainingDistance() {
        return getTargetPosition() - getMotorPosition();
    }

    public boolean isOverCurrent() {
        return dcMotorEx.isOverCurrent();
    }

    public boolean shouldStopPower() {
        return isOverCurrent() || atTargetPosition();
    }

    public static boolean isStoragePosition(int pos) {
        return pos == 1 || pos == 3 || pos == 5;
    }

    public static boolean isShootingPosition(int pos) {
        return pos == 2 || pos == 4 || pos == 6;
    }

    public static int getShootingPositionFor(int storagePosition) {
        if (isShootingPosition(storagePosition)) {
            throw new IllegalArgumentException("Invalid storage pos: " + storagePosition);
        }
        return getOppositePosition(storagePosition);
    }

    public static int getStoragePositionFor(int shootingPosition) {
        if (isStoragePosition(shootingPosition)) {
            throw new IllegalArgumentException("Invalid shooting pos: " + shootingPosition);
        }
        return getOppositePosition(shootingPosition);
    }

    /**
     * Set POSITION PIDF coefficients (Manual Control Loop)
     * These affect the response of the position controller.
     */
    public void setPIDF(double p, double i, double d, double f) {
        this.posP = p;
        this.posI = i;
        this.posD = d;
        this.posF = f;

        // Reset integral term when coefficients change
        this.accumulatedError = 0;
    }

    /**
     * Get current POSITION PIDF coefficients
     */
    public PIDFCoefficients getPIDF() {
        return new PIDFCoefficients(posP, posI, posD, posF);
    }

    public void setPositionControllerGains(double kP, double kD) {
        this.posP = kP;
        this.posD = kD;
    }

    public DcMotor.RunMode getRunMode() {
        return dcMotorEx.getMode();
    }

    public void setRunMode(DcMotor.RunMode mode) {
        dcMotorEx.setMode(mode);
    }

    public DcMotorEx getMoulinMotor() {
        return dcMotorEx;
    }
}
