package org.firstinspires.ftc.teamcode.dinitech.commands.groups;

import com.arcrobotics.ftclib.command.ConditionalCommand;
import com.arcrobotics.ftclib.command.InstantCommand;
import com.arcrobotics.ftclib.command.WaitCommand;

import org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.gamepad.Rumble;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.GamepadSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.ShooterSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.TrieurSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.VisionSubsystem;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.TRIEUR_TIME_BETWEEN_SHOTS;

public class ShootMotif extends ConditionalCommand {
    /**
     * Creates a ShootGreen Sequential Command Group
     * @param trieurSubsystem this command will run on
     * @param shooterSubsystem
     * @param visionSubsystem
     * @param gamepadSubsystem
     */

    public ShootMotif(TrieurSubsystem trieurSubsystem, ShooterSubsystem shooterSubsystem, VisionSubsystem visionSubsystem, GamepadSubsystem gamepadSubsystem){
        super(
                new InstantCommand(() -> {
                    // cache the order of the colors to shoot
                    String[] colorsOrder = visionSubsystem.getColorsOrder();

                    // For color in colors, create the list of moulin states to send.
                    for (String color : colorsOrder) {
                        if (color.equals("g")) {
                                new ShootColor(trieurSubsystem, shooterSubsystem, gamepadSubsystem, TrieurSubsystem.ArtifactColor.GREEN).schedule();
                                new WaitCommand(TRIEUR_TIME_BETWEEN_SHOTS).schedule();

                        } else if (color.equals("p")) {
                                new ShootColor(trieurSubsystem, shooterSubsystem, gamepadSubsystem, TrieurSubsystem.ArtifactColor.PURPLE).schedule();
                                new WaitCommand(TRIEUR_TIME_BETWEEN_SHOTS).schedule();

                        }
                    }
                }),
                new Rumble(gamepadSubsystem, 3, 1), // No color order detected
                visionSubsystem::hasColorOrder

        );
    }
}
