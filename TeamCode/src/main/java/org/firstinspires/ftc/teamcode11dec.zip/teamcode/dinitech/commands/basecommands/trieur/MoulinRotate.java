package org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.trieur;

import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.MOULIN_ROTATE_SPEED_CONTINUOUS;

import com.arcrobotics.ftclib.command.CommandBase;

import org.firstinspires.ftc.teamcode.dinitech.subsytems.TrieurSubsystem;

public class MoulinRotate extends CommandBase {
    private final TrieurSubsystem trieurSubsystem;

    /**
     * Creates a new MoulinRotateHoraire command.
     * 
     * @param trieurSubsystem the subsystem used by this command
     */
    public MoulinRotate(TrieurSubsystem trieurSubsystem) {
        this.trieurSubsystem = trieurSubsystem;
        addRequirements(trieurSubsystem);
    }

    @Override
    public void initialize() {
        trieurSubsystem.incrementMoulinTargetPosition(MOULIN_ROTATE_SPEED_CONTINUOUS);
    }

    @Override
    public boolean isFinished() {
        return trieurSubsystem.shouldMoulinStopPower();
    }

    @Override
    public void end(boolean interrupted) {
        // If command ended due to over-current (not interrupted), schedule correction
        if (!interrupted && trieurSubsystem.isMoulinOverCurrent()) {
            new MoulinCorrectOverCurrent(trieurSubsystem, this).schedule();
        }
    }
}
