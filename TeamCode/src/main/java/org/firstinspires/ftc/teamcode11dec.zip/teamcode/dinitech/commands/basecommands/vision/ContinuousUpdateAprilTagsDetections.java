package org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.vision;


import com.arcrobotics.ftclib.command.CommandBase;

import org.firstinspires.ftc.teamcode.dinitech.subsytems.VisionSubsystem;

public class ContinuousUpdateAprilTagsDetections extends CommandBase {
    private VisionSubsystem visionSubsystem;

    public ContinuousUpdateAprilTagsDetections(VisionSubsystem visionSubsystem){
        this.visionSubsystem = visionSubsystem;

        addRequirements(visionSubsystem);
    }

    @Override
    public void execute(){
        visionSubsystem.optimizeDecimation();
        visionSubsystem.updateAprilTagDetections();
    }
}
