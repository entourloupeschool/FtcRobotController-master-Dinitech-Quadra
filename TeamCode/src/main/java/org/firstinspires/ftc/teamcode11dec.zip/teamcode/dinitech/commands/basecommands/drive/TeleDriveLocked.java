package org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.drive;

import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.CLAMP_BEARING;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.NUMBER_CUSTOM_POWER_FUNC_DRIVE_LOCKED;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.OFFSET_BEARING_AT_134_INCHES_RANGE;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.OFFSET_BEARING_AT_50_INCHES_RANGE;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.pickCustomPowerFunc;
import static org.firstinspires.ftc.teamcode.dinitech.subsytems.VisionSubsystem.getLinearInterpolationOffsetBearing;

import com.arcrobotics.ftclib.command.CommandBase;
import com.arcrobotics.ftclib.gamepad.GamepadEx;
import com.arcrobotics.ftclib.gamepad.GamepadKeys;

import org.firstinspires.ftc.teamcode.dinitech.subsytems.DriveSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.GamepadSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.VisionSubsystem;

public class TeleDriveLocked extends CommandBase {
    private final DriveSubsystem driveSubsystem;
    private final VisionSubsystem visionSubsystem;

    private final GamepadEx driver;

    public TeleDriveLocked(DriveSubsystem driveSubsystem, VisionSubsystem visionSubsystem,
            GamepadSubsystem gamepadSubsystem) {
        this.driveSubsystem = driveSubsystem;
        this.visionSubsystem = visionSubsystem;

        driver = gamepadSubsystem.getDriverEx();

        addRequirements(driveSubsystem);
    }

    @Override
    public void execute() {
        if (visionSubsystem.getHasCurrentAprilTagDetections()) {
            withCurrentDetection();
        } else {
            // Use field-centric teleDrive (already implemented in DriveSubsystem)
            driveSubsystem.teleDrive(driver.getLeftX(), driver.getLeftY(), driver.getRightX(),
                    driver.getTrigger(GamepadKeys.Trigger.RIGHT_TRIGGER));
        }
    }

    /**
     * Execute driving with AprilTag auto-aim enabled
     */
    private void withCurrentDetection() {
        double rotationPower = 0;
        double rightX = driver.getRightX();
        // Linear interpolation of offset based on range
        double robotCenterBearing = visionSubsystem.getRobotCenterBearing();

        // Clamp robot bearing to -30 to 30 degrees and normalize to -1 to 1 range
        double normalizedClampedBearing = Math.max(-CLAMP_BEARING,
                Math.min(CLAMP_BEARING, robotCenterBearing)) / CLAMP_BEARING;

        rotationPower -= pickCustomPowerFunc(normalizedClampedBearing, NUMBER_CUSTOM_POWER_FUNC_DRIVE_LOCKED)
                * (1 - Math.abs(rightX));

        rotationPower += rightX;

        driveSubsystem.teleDrive(driver.getLeftX(), driver.getLeftY(), rotationPower,
                driver.getTrigger(GamepadKeys.Trigger.RIGHT_TRIGGER));
    }

}
