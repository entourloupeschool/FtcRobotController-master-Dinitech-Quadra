package org.firstinspires.ftc.teamcode.dinitech.subsytems.devices;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.TRAPPE_CLOSE_POSITION;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.TRAPPE_OPEN_POSITION;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.TRAPPE_SERVO_NAME;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.TRAPPE_TELE_INCREMENT;

import com.qualcomm.robotcore.hardware.HardwareMap;

public class Trappe extends SingleServo {
    /** State of the door (open/closed) */
    private boolean doorIsOpen = false;

    /**
     * Construct the door.
     * @param hardwareMap FTC hardware map
     */
    public Trappe(final HardwareMap hardwareMap){
        super(hardwareMap);
        close();
    }


    /**
     * @return The name of the door servo
     */
    public String getName() {
        return TRAPPE_SERVO_NAME;
    }

    /**
     * Open the door to the predefined open position.
     */
    public void open() {
        rotateToPosition(TRAPPE_OPEN_POSITION);
        doorIsOpen = true;
    }


    /**
     * Close the door to the predefined closed position.
     */
    public void close() {
        rotateToPosition(TRAPPE_CLOSE_POSITION);
        doorIsOpen = false;
    }

    /**
     * @return True if the door is open
     */
    public boolean isDoorOpen() {
        return doorIsOpen;
    }

    public void toggleTrappe(){
        /**
         * Toggle the door state (open/close)
         */
        if (isDoorOpen()){
            close();
        } else{
            open();
        }
    }

    /**
     * Incrementally rotate the door up, with range check.
     */
    public void incrementalRotationUp() {
        double targetPosition = this.getAngle() + TRAPPE_TELE_INCREMENT;
        if (targetPosition < TRAPPE_OPEN_POSITION) rotateToPosition(targetPosition);
    }

    /**
     * Incrementally rotate the door down, with range check.
     */
    public void incrementalRotationDown() {
        double targetPosition = this.getAngle() - TRAPPE_TELE_INCREMENT;
        if (targetPosition > TRAPPE_CLOSE_POSITION) rotateToPosition(targetPosition);
    }

    /**
     * Rotate the claw to a specific position, clamped to allowed range.
     */
    public void rotateToPosition(final double targetPosition) {
        this.rotate(targetPosition);
    }

}
