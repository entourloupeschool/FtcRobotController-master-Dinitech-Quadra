package org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.trieur;

import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.OVER_CURRENT_BACKOFF_TICKS;

import com.arcrobotics.ftclib.command.CommandBase;
import com.arcrobotics.ftclib.command.SequentialCommandGroup;

import org.firstinspires.ftc.teamcode.dinitech.subsytems.TrieurSubsystem;

/**
 * Command that handles over-current protection for the Moulin motor.
 * When over-current is detected, it backs off the motor by
 * OVER_CURRENT_BACKOFF_TICKS,
 * then schedules the original command to resume movement to the target.
 */
public class MoulinCorrectOverCurrent extends CommandBase {
    private final TrieurSubsystem trieurSubsystem;
    private final CommandBase originalCommand;
    private int savedRemainingDistance;

    /**
     * Creates a new MoulinCorrectOverCurrent command.
     * 
     * @param trieurSubsystem the subsystem used by this command
     * @param originalCommand the command that was interrupted by over-current
     */
    public MoulinCorrectOverCurrent(TrieurSubsystem trieurSubsystem, CommandBase originalCommand) {
        this.trieurSubsystem = trieurSubsystem;
        this.originalCommand = originalCommand;

        addRequirements(trieurSubsystem);
    }

    @Override
    public void initialize() {
        // save remaining Distance
        savedRemainingDistance = Math.abs(trieurSubsystem.getMoulinMotorRemainingDistance());

        // Back off by decreasing the target position
        trieurSubsystem
                .incrementMoulinTargetPosition(- OVER_CURRENT_BACKOFF_TICKS);
    }

    @Override
    public boolean isFinished() {
        // Finish when we've backed off and restored the target
        return trieurSubsystem.shouldMoulinStopPower();
    }

    @Override
    public void end(boolean interrupted) {
        trieurSubsystem.incrementMoulinTargetPosition(savedRemainingDistance);

        // Resume the original command if not interrupted
        if (!interrupted && originalCommand != null) {
            originalCommand.schedule();
        }
    }
}
