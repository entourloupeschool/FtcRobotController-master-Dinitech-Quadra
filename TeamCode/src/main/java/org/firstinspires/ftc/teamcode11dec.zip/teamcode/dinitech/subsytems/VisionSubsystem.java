package org.firstinspires.ftc.teamcode.dinitech.subsytems;

import com.acmerobotics.roadrunner.Pose2d;
import com.qualcomm.robotcore.hardware.HardwareMap;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.CX;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.CY;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.FX;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.FY;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.CAMERA1_NAME;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.CAMERA_ORIENTATION;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.CAMERA_POSITION;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.CAMERA_RESOLUTION;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.NUMBER_AT_SAMPLES;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.OFFSET_BEARING_AT_134_INCHES_RANGE;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.OFFSET_BEARING_AT_50_INCHES_RANGE;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.STREAM_FORMAT;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.USE_WEBCAM;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.OFFSET_ROBOT_X;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.OFFSET_ROBOT_Y;
import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.OFFSET_ROBOT_YAW;

import com.arcrobotics.ftclib.command.SubsystemBase;

import org.firstinspires.ftc.robotcore.external.Telemetry;
import org.firstinspires.ftc.robotcore.external.hardware.camera.BuiltinCameraDirection;
import org.firstinspires.ftc.robotcore.external.hardware.camera.WebcamName;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.vision.VisionPortal;
import org.firstinspires.ftc.vision.apriltag.AprilTagDetection;
import org.firstinspires.ftc.vision.apriltag.AprilTagGameDatabase;
import org.firstinspires.ftc.vision.apriltag.AprilTagProcessor;
import org.firstinspires.ftc.vision.opencv.ImageRegion;
import org.firstinspires.ftc.vision.opencv.PredominantColorProcessor;

import java.util.List;
import java.util.Locale;

public class VisionSubsystem extends SubsystemBase {
    /** Telemetry for reporting drive status */
    public final Telemetry telemetry;

    /**
     * The variable to store our instance of the vision portal.
     */
    public VisionPortal.Builder builder = null;

    // Store processor references as class fields so we can check if they're null
    public AprilTagProcessor aprilTagProcessor;
    public PredominantColorProcessor colorProcessor;

    // Sample lists for averaging AprilTag pose data
    // Sample lists for averaging AprilTag pose data
    private final RunningAverage robotPoseXSamples = new RunningAverage(NUMBER_AT_SAMPLES);
    private final RunningAverage robotPoseYSamples = new RunningAverage(NUMBER_AT_SAMPLES);
    private final RunningAverage robotPoseYawSamples = new RunningAverage(NUMBER_AT_SAMPLES);
    private final RunningAverage rangeToAprilTagSamples = new RunningAverage(NUMBER_AT_SAMPLES);
    private final RunningAverage cameraBearingSamples = new RunningAverage(NUMBER_AT_SAMPLES);
    private final RunningAverage confidenceAprilTagSamples = new RunningAverage(NUMBER_AT_SAMPLES);
    private boolean hasCurrentATDetections = false; // True if latest update found detections

    // Cached color order - set once at game start and never changes
    private String[] cachedColorsOrder = new String[0];
    private boolean hasDetectedColorOrder = false;

    private int currentDecimation = 1;

    public VisionSubsystem(HardwareMap hardwareMap, final Telemetry telemetry) {
        // Create the vision portal by using a builder.
        this.builder = new VisionPortal.Builder();
        this.aprilTagProcessor = null;
        this.colorProcessor = null;

        // Set the camera (webcam vs. built-in RC phone camera).
        if (USE_WEBCAM) {
            builder.setCamera(hardwareMap.get(WebcamName.class, CAMERA1_NAME))
                    .setStreamFormat(STREAM_FORMAT)
                    .setCameraResolution(CAMERA_RESOLUTION)
                    // Enable the RC preview (LiveView). Set "false" to omit camera monitoring.
                    .enableLiveView(false);
        } else {
            builder.setCamera(BuiltinCameraDirection.BACK);
        }

        this.telemetry = telemetry;
    }

    /**
     * Build the vision portal after processors have been added
     */
    public void buildVisionPortal() {
        if (builder != null) {
            builder.build();
        }
    }

    /**
     * Method to add processors to the vision portal.
     */
    public void addAprilTagProcessor() {
        // Create the AprilTag processor.
        aprilTagProcessor = new AprilTagProcessor.Builder()
                .setLensIntrinsics(FX, FY, CX, CY)
                .setTagLibrary(AprilTagGameDatabase.getDecodeTagLibrary())
                .setDrawCubeProjection(true)
                .setDrawAxes(true)
                .setCameraPose(CAMERA_POSITION, CAMERA_ORIENTATION)
                .build();

        // Adjust Image Decimation to trade-off detection-range for detection-rate.
        // eg: Some typical detection data using a Logitech C920 WebCam
        // Decimation = 1 .. Detect 2" Tag from 10 feet away at 10 Frames per second
        // Decimation = 2 .. Detect 2" Tag from 6 feet away at 22 Frames per second
        // Decimation = 3 .. Detect 2" Tag from 4 feet away at 30 Frames Per Second
        // (default)
        // Decimation = 3 .. Detect 5" Tag from 10 feet away at 30 Frames Per Second
        // (default)
        // Note: Decimation can be changed on-the-fly to adapt during a match.
        setAprilTagDetectionDecimation(getCurrentDecimation()); // Maximizing accuracy over fps; could be changed?

        // Add the AprilTag processor to the vision portal.
        builder.addProcessor(aprilTagProcessor);
    }

    /**
     * Method to add color processor
     */
    public void addColorProcessor(final double size) {
        // Create the color processor.
        colorProcessor = new PredominantColorProcessor.Builder()
                .setRoi(ImageRegion.asUnityCenterCoordinates(-size, size, size, -size))
                .setSwatches(
                        PredominantColorProcessor.Swatch.ARTIFACT_GREEN,
                        PredominantColorProcessor.Swatch.ARTIFACT_PURPLE)
                .build();

        // Add the color processor to the vision portal.
        builder.addProcessor(colorProcessor);
    }

    /**
     * Updates the cached AprilTag detection data if new detections are available.
     * If AprilTag processor is available and detections exist, updates cached
     * values.
     * If not available, retains the latest cached values.
     * If never detected, values remain null.
     */
    public void updateAprilTagDetections() {
        // Check if AprilTag processor is available
        if (aprilTagProcessor != null) {
            List<AprilTagDetection> detections = aprilTagProcessor.getDetections();

            // Update cached values only if we have detections
            if (!detections.isEmpty()) {
                AprilTagDetection detection = detections.get(0); // Use first (best) detection

                // Check if the detection has valid robot pose data
                if (detection.metadata != null) {
                    // Only update pose for navigation tags (20, 24)
                    if (detection.id == 20 || detection.id == 24) {
                        // Positional AprilTags detection
                        setHasCurrentAprilTagDetections(true);

                        // Add samples to lists for averaging
                        robotPoseXSamples.add(detection.robotPose.getPosition().x);
                        robotPoseYSamples.add(detection.robotPose.getPosition().y);
                        robotPoseYawSamples.add(detection.robotPose.getOrientation().getYaw(AngleUnit.RADIANS));
                        cameraBearingSamples.add(detection.ftcPose.bearing);
                        rangeToAprilTagSamples.add(detection.ftcPose.range);
                        confidenceAprilTagSamples.add(detection.decisionMargin);
                    } else {
                        // Reset current detection flag
                        setHasCurrentAprilTagDetections(false);
                    }

                    // Cache color order only if not already detected (set once per game)
                    if (!hasDetectedColorOrder) {
                        if (detection.id == 21) {
                            cachedColorsOrder = new String[] { "g", "p", "p" };
                            hasDetectedColorOrder = true;
                        } else if (detection.id == 22) {
                            cachedColorsOrder = new String[] { "p", "g", "p" };
                            hasDetectedColorOrder = true;
                        } else if (detection.id == 23) {
                            cachedColorsOrder = new String[] { "p", "p", "g" };
                            hasDetectedColorOrder = true;
                        }
                    }

                } else {
                    // Reset current detection flag
                    setHasCurrentAprilTagDetections(false);
                }
            } else {
                // Reset current detection flag
                setHasCurrentAprilTagDetections(false);
            }
            // If no detections, keep the cached values unchanged but update the flag
        } else {
            // Reset current detection flag
            setHasCurrentAprilTagDetections(false);
        }
        // If processor is null, keep everything unchanged including the flag as false
    }

    /**
     * A zero-allocation circular buffer for calculating running averages.
     */
    private static class RunningAverage {
        private final double[] samples;
        private int index = 0;
        private int count = 0;
        private double runningSum = 0;

        public RunningAverage(int size) {
            this.samples = new double[size];
        }

        public void add(double value) {
            if (count < samples.length) {
                // Filling the buffer
                samples[index] = value;
                runningSum += value;
                count++;
            } else {
                // Overwriting oldest sample
                runningSum -= samples[index];
                samples[index] = value;
                runningSum += value;
            }
            index = (index + 1) % samples.length;
        }

        public Double getAverage() {
            if (count == 0)
                return null;
            return runningSum / count;
        }

        public boolean isEmpty() {
            return count == 0;
        }

        public int size() {
            return count;
        }
    }

    /**
     * Get the averaged robot pose X coordinate
     * 
     * @return Averaged robot pose X or null if no samples
     */
    public Double getRobotPoseX() {
        return robotPoseXSamples.getAverage();
    }

    /**
     * Get the averaged robot pose Y coordinate
     * 
     * @return Averaged robot pose Y or null if no samples
     */
    public Double getRobotPoseY() {
        return robotPoseYSamples.getAverage();
    }

    /**
     * Get the averaged robotPose Yaw
     * 
     * @return Averaged robot pose Yaw or null if no samples
     */
    public Double getRobotPoseYaw() {
        return robotPoseYawSamples.getAverage();
    }

    /**
     * Get the averaged rangeToAprilTag
     *
     * @return Averaged rangeToAprilTag or null if no samples
     */
    public Double getRangeToAprilTag() {
        return rangeToAprilTagSamples.getAverage();
    }

    /**
     * Get the averaged robot bearing to AprilTag
     * 
     * @return Averaged robot bearing or null if no samples
     */
    public Double getCameraBearing() {
        return cameraBearingSamples.getAverage();
    }

    public double getRobotCenterBearing(){
        return getCameraBearing() - getLinearInterpolationOffsetBearing(getRangeToAprilTag());
    }
    /**
     * Check if the latest updateAprilTagDetections() call found any detections
     * 
     * @return true if current update cycle detected AprilTags
     */
    public boolean getHasCurrentAprilTagDetections() {
        return hasCurrentATDetections;
    }

    public void setHasCurrentAprilTagDetections(boolean newHasCurrentATDetections) {
        hasCurrentATDetections = newHasCurrentATDetections;
    }

    /**
     * Check if we have any pose data samples available
     * 
     * @return true if robot pose data samples have been collected
     */
    public boolean hasCachedPoseData() {
        return !robotPoseXSamples.isEmpty() || !robotPoseYSamples.isEmpty() || !cameraBearingSamples.isEmpty();
    }

    public Pose2d getLatestRobotPoseEstimationFromAT() {
        Double x = getRobotPoseX();
        Double y = getRobotPoseY();
        Double yaw = getRobotPoseYaw();

        return new Pose2d(
                x != null ? x : 0.0,
                y != null ? y : 0.0,
                yaw != null ? yaw : 0.0);
    }

    private void setAprilTagDetectionDecimation(int dec) {
        aprilTagProcessor.setDecimation((float) dec);
    }

    public void optimizeDecimation() {
        // Adjust Image Decimation to trade-off detection-range for detection-rate.
        // eg: Some typical detection data using a Logitech C920 WebCam
        // Decimation = 1 .. Detect 2" Tag from 10 feet away at 10 Frames per second
        // Decimation = 2 .. Detect 2" Tag from 6 feet away at 22 Frames per second
        // Decimation = 3 .. Detect 2" Tag from 4 feet away at 30 Frames Per Second
        // (default)
        // Decimation = 3 .. Detect 5" Tag from 10 feet away at 30 Frames Per Second
        // (default)
        // Note: Decimation can be changed on-the-fly to adapt during a match.
        if (aprilTagProcessor == null) {
            return;
        }
        // get Last rangeToAprilTag
        Double rangeToAprilTag = getRangeToAprilTag(); // Inches
        if (rangeToAprilTag == null) {
            return;
        }

        // minimun range is 25 inches, maximum range is 80.
        // At range 35, decimation should be 4.
        // At range 80, decimation should be 1.

        // Linear interpolation: range [80, 35] maps to decimation [1, 4]
        int optimalDecimation = (int) Math.round(4.0 - 3.0 * (rangeToAprilTag - 35) / 45.0);
        optimalDecimation = Math.max(1, Math.min(4, optimalDecimation));
        setCurrentDecimation(optimalDecimation);
        setAprilTagDetectionDecimation(optimalDecimation);
    }

    public int getCurrentDecimation(){
        return currentDecimation;
    }
    public void setCurrentDecimation(int newDecimation){
        currentDecimation = newDecimation;
    }

    public static double getLinearInterpolationOffsetBearing(double range) {
        if (range < 50) {
            return OFFSET_BEARING_AT_50_INCHES_RANGE;
        } else if (range < 134) {
            return OFFSET_BEARING_AT_134_INCHES_RANGE;
        } else {
            return OFFSET_BEARING_AT_134_INCHES_RANGE + (range - 134)
                    * (OFFSET_BEARING_AT_134_INCHES_RANGE - OFFSET_BEARING_AT_50_INCHES_RANGE) / (134 - 50);
        }
    }

    /**
     * Periodic updates and telemetry reporting for vision subsystem.
     */
    @Override
    public void periodic() {
        printTelemetry(telemetry);
    }

    /**
     * telemetry funciton to draw on driverHub
     */
    private void printTelemetry(final Telemetry telemetry) {
        // Check if builder null
        if (builder == null) {
            telemetry.addLine("Builder is null");
        } else {
            // Check if AprilTag processor exists (not null)
            if (aprilTagProcessor != null) {
                aprilTagProcessorTelemetry();
            }

            // Check if Color processor exists (not null)
            if (colorProcessor != null) {
                colorProcessorTelemetry();
            }

            // If both processors are null
            if (aprilTagProcessor == null && colorProcessor == null) {
                telemetry.addData("Vision", "No processors added");
            }
        }
    }

    private void aprilTagProcessorTelemetry() {
        // Show current detection status
        telemetry.addData("Current AT Detections", getHasCurrentAprilTagDetections() ? "Yes" : "No");

        // Show averaged values (if available) and sample counts
        if (hasCachedPoseData()) {
            telemetry.addData("X", String.format(Locale.US, "%.2f (%d samples)",
                    getRobotPoseX() != null ? getRobotPoseX() : 0.0, robotPoseXSamples.size()));
            telemetry.addData("X Offset", String.format(Locale.US, "%.2f (%d samples)",
                    getRobotPoseX() != null ? getRobotPoseX() - OFFSET_ROBOT_X : 0.0, robotPoseXSamples.size()));
            telemetry.addData("Y", String.format(Locale.US, "%.2f (%d samples)",
                    getRobotPoseY() != null ? getRobotPoseY() : 0.0, robotPoseYSamples.size()));
            telemetry.addData("Y Offset", String.format(Locale.US, "%.2f (%d samples)",
                    getRobotPoseY() != null ? getRobotPoseY() - OFFSET_ROBOT_Y : 0.0, robotPoseYSamples.size()));
            telemetry.addData("Yaw", String.format(Locale.US, "%.2f (%d samples)",
                    getRobotPoseYaw() != null ? getRobotPoseYaw() : 0.0, robotPoseYawSamples.size()));
            telemetry.addData("Yaw Offset", String.format(Locale.US, "%.2f (%d samples)",
                    getRobotPoseYaw() != null ? getRobotPoseYaw() + Math.toDegrees(OFFSET_ROBOT_YAW) : 0.0,
                    robotPoseYawSamples.size()));
            telemetry.addData("Bearing", String.format(Locale.US, "%.2f (%d samples)",
                    getCameraBearing() != null ? getCameraBearing() : 0.0, cameraBearingSamples.size()));
            telemetry.addData("Bearing Offset", String.format(Locale.US, "%.2f (%d samples)",
                    getCameraBearing() != null
                            ? getRobotCenterBearing()
                            : 0.0,
                    cameraBearingSamples.size()));
            telemetry.addData("Range", String.format(Locale.US, "%.2f (%d samples)",
                    getRangeToAprilTag() != null ? getRangeToAprilTag() : 0.0, rangeToAprilTagSamples.size()));
//            telemetry.addData("Confidence", String.format(Locale.US, "%.2f (%d samples)",
//                    confidenceAprilTagSamples.getAverage() != null ? confidenceAprilTagSamples.getAverage() : 0.0,
//                    confidenceAprilTagSamples.size()));
        } else {
            telemetry.addData("AprilTag Pose Data", "No sample data");
        }

        telemetry.addData("decimation", getCurrentDecimation());

        // Show color order status
        if (hasDetectedColorOrder) {
            telemetry.addData("Artifact Color Order", String.format(Locale.US, "[%s, %s, %s]",
                    cachedColorsOrder[0], cachedColorsOrder[1], cachedColorsOrder[2]));
        }
    }

    private void colorProcessorTelemetry() {
        PredominantColorProcessor.Result result = colorProcessor.getAnalysis();
        if (result != null) {
            telemetry.addData("Predominant Color", result.closestSwatch);
        } else {
            telemetry.addData("Predominant Color", "No analysis available");
        }
    }

    /**
     * Get the cached color order (determined once at game start)
     * 
     * @return Array of color order, or null if not yet detected
     */
    public String[] getColorsOrder() {
        return cachedColorsOrder;
    }

    /**
     * Check if the color order has been detected and cached
     * 
     * @return true if color order is available
     */
    public boolean hasColorOrder() {
        return hasDetectedColorOrder;
    }

    /**
     * Reset the color order cache (useful for testing or new games)
     */
    public void resetColorOrder() {
        cachedColorsOrder = null;
        hasDetectedColorOrder = false;
    }
}
