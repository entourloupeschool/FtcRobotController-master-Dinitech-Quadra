package org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.trieur;

import org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.gamepad.InstantRumbleCustom;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.GamepadSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.TrieurSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.VisionSubsystem;

public class ReadyMotif extends MoulinToPosition {
    private final TrieurSubsystem trieurSubsystem;
    private final VisionSubsystem visionSubsystem;
    private final GamepadSubsystem gamepadSubsystem;

    public ReadyMotif(TrieurSubsystem trieurSubsystem, VisionSubsystem visionSubsystem, GamepadSubsystem gamepadSubsystem){
        // Pass dummy values to super() - we'll set the real target in initialize()
        super(trieurSubsystem, 0, false);
        this.trieurSubsystem = trieurSubsystem;
        this.visionSubsystem = visionSubsystem;
        this.gamepadSubsystem = gamepadSubsystem;
    }

    @Override
    public void initialize(){
        // check if colorsOrder has been detected
        if (!visionSubsystem.hasColorOrder()){
            new InstantRumbleCustom(gamepadSubsystem, 3, 0.5).schedule();
            makeShort = false;
            moulinTargetPosition = trieurSubsystem.getNNextMoulinPosition(trieurSubsystem.getClosestShootingPositionForColor(trieurSubsystem.getLastDetectedColor()), 1);
            super.initialize();

            return;
        }
        // cache the order of the colors to shoot
        String[] colorsOrder = visionSubsystem.getColorsOrder();

        // Get the position of the purple artefact
        int purplePosition = -1;
        for (int i = 0; i < colorsOrder.length; i++){
            if (colorsOrder[i].equals("g")){
                purplePosition = i + 1; // positions are 1-indexed
                break;
            }
        }

        // if the purple artefact is first then the purple moulinState must be on the shooting position.
        // if the purple artefact is second then the purple state must be one position after the shooting position.
        // if the purple artefact is third then the purple state must be two positions after the shooting position.
        moulinTargetPosition = trieurSubsystem.getNPreviousMoulinPosition(trieurSubsystem.getClosestShootingPositionForColor(TrieurSubsystem.ArtifactColor.GREEN), 1);
        if (purplePosition == 2){
            moulinTargetPosition = trieurSubsystem.getNPreviousMoulinPosition(moulinTargetPosition, 3);
        } else if (purplePosition == 3){
            moulinTargetPosition = trieurSubsystem.getNPreviousMoulinPosition(moulinTargetPosition, 5);
        }

        makeShort = false;

        super.initialize();
    }
}
