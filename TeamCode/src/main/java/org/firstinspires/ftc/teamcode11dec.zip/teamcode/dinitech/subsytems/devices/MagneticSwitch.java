package org.firstinspires.ftc.teamcode.dinitech.subsytems.devices;

import static org.firstinspires.ftc.teamcode.dinitech.other.Globals.MAGNETIC_SWITCH_NAME;

import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.TouchSensor;

public class MagneticSwitch {
    public final TouchSensor magneticSwitch;

    public MagneticSwitch(HardwareMap hardwareMap){
        this.magneticSwitch = hardwareMap.get(TouchSensor.class, MAGNETIC_SWITCH_NAME);
    }

    public boolean isMagnetic(){
        return magneticSwitch.isPressed();
    }

    public double getMagneticValue(){
        return magneticSwitch.getValue();
    }
}
