package org.firstinspires.ftc.teamcode.dinitech.commands.groups;

import com.arcrobotics.ftclib.command.ParallelDeadlineGroup;
import com.arcrobotics.ftclib.command.RepeatCommand;
import com.arcrobotics.ftclib.command.StartEndCommand;
import com.arcrobotics.ftclib.command.WaitUntilCommand;

import org.firstinspires.ftc.teamcode.dinitech.other.Globals;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.ChargeurSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.GamepadSubsystem;
import org.firstinspires.ftc.teamcode.dinitech.subsytems.TrieurSubsystem;

public class AutomaticArtefactPickAway extends ParallelDeadlineGroup {
    /**
     * Creates a AutomaticArtefactPickAway Parallel Deadline Group
     * 
     * @param trieurSubsystem   this command will run on
     */

    public AutomaticArtefactPickAway(TrieurSubsystem trieurSubsystem, ChargeurSubsystem chargeurSubsystem,
            GamepadSubsystem gamepadSubsystem) {
        super(
                // Deadline: Stop everything when the trieur is full
                new WaitUntilCommand(trieurSubsystem::getIsFull),

                // 1. Keep Chargeur running at max power, stop when done
                new StartEndCommand(
                        () -> chargeurSubsystem.setPower(Globals.CHARGEUR_MOTOR_POWER),
                        () -> chargeurSubsystem.setPower(0),
                        chargeurSubsystem),

                // 2. Continuously run the pick-up sequence
                new RepeatCommand(new ArtefactPickAway(trieurSubsystem, gamepadSubsystem))
        );
    }
}
