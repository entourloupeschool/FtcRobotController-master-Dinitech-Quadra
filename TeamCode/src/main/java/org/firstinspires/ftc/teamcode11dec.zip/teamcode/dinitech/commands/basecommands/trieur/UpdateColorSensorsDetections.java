package org.firstinspires.ftc.teamcode.dinitech.commands.basecommands.trieur;

import com.arcrobotics.ftclib.command.CommandBase;

import org.firstinspires.ftc.teamcode.dinitech.subsytems.TrieurSubsystem;

public class UpdateColorSensorsDetections extends CommandBase {
    private TrieurSubsystem trieurSubsystem;
    private final int numberSample;

    public UpdateColorSensorsDetections(TrieurSubsystem trieurSubsystem, int numberSample){
        this.trieurSubsystem = trieurSubsystem;
        this.numberSample = numberSample;
    }
    @Override
    public void initialize(){
        /**
         * Clear the color detection data
         */
        trieurSubsystem.clearSamplesColorSensors();
    }

    @Override
    public void execute(){
        /**
         * Update the color detection data
         */
        trieurSubsystem.updateColorSensors();
    }


    @Override
    public boolean isFinished() {
        return trieurSubsystem.getColorSensorSampleCount() >= numberSample;
    }

    @Override
    public void end(boolean interrupted) {
        // cut power and clean up
        trieurSubsystem.registerArtefact();
    }
}
